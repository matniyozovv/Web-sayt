// News data - Kengaytirilgan
const newsData = [
    {
        id: 1,
        image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400",
        category: "Fan",
        title: "Fizika fanidan ochiq dars",
        date: "5-fevral, 2026",
        views: 156,
        description: "10-sinf o'quvchilari uchun fizika fanidan ochiq dars bo'lib o'tdi.",
        fullContent: "10-sinf o'quvchilari uchun fizika fanidan ochiq dars bo'lib o'tdi. Darsda 50 dan ortiq o'quvchi qatnashdi. O'qituvchi A. Karimov tomonidan 'Elektr toki' mavzusida qiziqarli tajribalar o'tkazildi.",
        link: "#",
        author: "Admin",
        importance: "medium"
    },
    {
        id: 2,
        image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=400",
        category: "Texnologiya",
        title: "Robototexnika to'garagi ochildi",
        date: "4-fevral, 2026",
        views: 189,
        description: "Maktabimizda yangi robototexnika to'garagi o'z faoliyatini boshladi.",
        fullContent: "Maktabimizda yangi robototexnika to'garagi o'z faoliyatini boshladi. To'garakka 5-9 sinf o'quvchilari qatnashishi mumkin. Mashg'ulotlar har hafta seshanba va payshanba kunlari soat 15:00 dan 17:00 gacha.",
        link: "#",
        author: "IT bo'limi",
        importance: "high"
    },
    {
        id: 3,
        image: "https://vollebol.uz/_next/static/media/main.ef96830b.jpg",
        category: "Sport",
        title: "Voleybol bo'yicha maktab chempionati",
        date: "3-fevral, 2026",
        views: 210,
        description: "Maktab jamoalari o'rtasida voleybol musobaqasi bo'lib o'tdi.",
        fullContent: "Maktab jamoalari o'rtasida voleybol musobaqasi bo'lib o'tdi. Finalda 11-sinf jamoasi 10-sinf jamoasini 3:1 hisobida mag'lub etib, chempion bo'ldi.",
        link: "#",
        author: "Sport bo'limi",
        importance: "high"
    },
    {
        id: 4,
        image: "https://www.gazeta.uz/media/img/2016/03/Dpdgac14585456322181_l.jpg",
        category: "Madaniyat",
        title: "Navro'z bayramiga tayyorgarlik",
        date: "2-fevral, 2026",
        views: 145,
        description: "Navro'z bayrami uchun badiiy chiqishlar tayyorlanmoqda.",
        fullContent: "Navro'z bayrami uchun badiiy chiqishlar tayyorlanmoqda. 20 dan ortiq o'quvchi qatnashadigan konsert dasturi tayyorlanmoqda. Milliy liboslar namoyishi bo'lib o'tadi.",
        link: "#",
        author: "Madaniyat bo'limi",
        importance: "medium"
    },
    {
        id: 5,
        image: "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=400",
        category: "Ta'lim",
        title: "O'qituvchilar kuni",
        date: "1-fevral, 2026",
        views: 167,
        description: "O'qituvchilar kuni munosabati bilan tadbir o'tkazildi.",
        fullContent: "O'qituvchilar kuni munosabati bilan tadbir o'tkazildi. 50 dan ortiq o'qituvchi tabriklanib, 10 nafar o'qituvchi faxriy yorliqlar bilan taqdirlandi.",
        link: "#",
        author: "Admin",
        importance: "medium"
    },
    {
        id: 6,
        image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400",
        category: "Loyiha",
        title: "Ekologik loyiha tanlovi",
        date: "30-yanvar, 2026",
        views: 98,
        description: "Eng yaxshi ekologik loyiha tanlovi e'lon qilindi.",
        fullContent: "Eng yaxshi ekologik loyiha tanlovi e'lon qilindi. G'olib loyiha mualliflari 500 000 so'm pul mukofoti bilan taqdirlanadi.",
        link: "#",
        author: "Ekologiya klubi",
        importance: "low"
    }
];

// Breaking news - Kengaytirilgan (20+ xabar)
const breakingNews = [
    {
        id: 1,
        icon: "🚨",
        title: "10-mart kuni 'Ochiq eshiklar kuni' bo'lib o'tadi!",
        description: "Ota-onalar va abituriyentlar uchun maktab bilan tanishish kuni. Soat 10:00 dan 15:00 gacha.",
        date: "2026-03-10",
        time: "10:00",
        category: "event",
        importance: "high"
    },
    {
        id: 2,
        icon: "📢",
        title: "Matematika olimpiadasiga ro'yxatdan o'tish boshlandi",
        description: "5-11 sinf o'quvchilari uchun maktab ichki matematika olimpiadasi.",
        date: "2026-03-15",
        time: "09:00",
        category: "competition",
        importance: "high"
    },
    {
        id: 3,
        icon: "🎭",
        title: "15-mart kuni 'Yosh iste'dodlar' tanlovi o'tkaziladi",
        description: "Qo'shiq, raqs va she'riyat yo'nalishlarida o'quvchilar o'rtasida tanlov.",
        date: "2026-03-15",
        time: "14:00",
        category: "cultural",
        importance: "medium"
    },
    {
        id: 4,
        icon: "📚",
        title: "Kutubxonaga 1000 ta yangi kitob kelib tushdi",
        description: "Badiiy, ilmiy va o'quv adabiyotlari. Barcha kitoblar katalogga kiritilgan.",
        date: "2026-03-05",
        time: "09:00",
        category: "library",
        importance: "medium"
    },
    {
        id: 5,
        icon: "🏀",
        title: "Basketbol bo'yicha maktab chempionati finali",
        description: "10-sinf va 11-sinf jamoalari o'rtasida final o'yini.",
        date: "2026-03-18",
        time: "15:00",
        category: "sport",
        importance: "high"
    },
    {
        id: 6,
        icon: "⚽",
        title: "Mini-futbol turniri",
        description: "Sinf jamoalari o'rtasida musobaqa. 3 ta guruhda o'tkaziladi.",
        date: "2026-03-20",
        time: "10:00",
        category: "sport",
        importance: "medium"
    },
    {
        id: 7,
        icon: "🔬",
        title: "Kimyo fanidan ochiq laboratoriya darsi",
        description: "9-sinf o'quvchilari bilan 'Kislotalar va asoslar' mavzusida tajriba darsi.",
        date: "2026-03-12",
        time: "13:00",
        category: "academic",
        importance: "medium"
    },
    {
        id: 8,
        icon: "💻",
        title: "Robototexnika to'garagiga qabul",
        description: "5-7 sinf o'quvchilari uchun bepul robototexnika kurslari.",
        date: "2026-03-08",
        time: "16:00",
        category: "technology",
        importance: "high"
    },
    {
        id: 9,
        icon: "🌍",
        title: "Xalqaro forumda ishtirok",
        description: "O'zbekiston - Koreya ta'lim forumi. Maktabimizdan 3 nafar o'qituvchi qatnashadi.",
        date: "2026-03-25",
        time: "09:00",
        category: "international",
        importance: "high"
    },
    {
        id: 10,
        icon: "🎨",
        title: "Rassomchilik ko'rgazmasi",
        description: "O'quvchilarning 50 dan ortiq rasmlari ko'rgazmasi.",
        date: "2026-03-16",
        time: "11:00",
        category: "art",
        importance: "medium"
    }
];

// Kategoriya ranglari
const categoryColors = {
    event: "#ff4757",
    competition: "#ff6b81",
    cultural: "#ffa502",
    library: "#7bed9f",
    sport: "#1e90ff",
    academic: "#5352ed",
    technology: "#a55eea",
    international: "#ff6348",
    art: "#ff7f50"
};

// Kategoriya nomlari
const categoryNames = {
    event: "Tadbir",
    competition: "Tanlov",
    cultural: "Madaniy",
    library: "Kutubxona",
    sport: "Sport",
    academic: "O'quv",
    technology: "Texnologiya",
    international: "Xalqaro",
    art: "San'at"
};

// Load news into grids
function loadNews() {
    // Load news for home page
    const newsContainer = document.getElementById('newsContainer');
    if (newsContainer) {
        newsContainer.innerHTML = newsData.map(news => `
            <div class="news-card" onclick="showNewsDetails(${news.id})">
                <img src="${news.image}" alt="${news.title}">
                <div class="card-content">
                    <span class="news-category" style="background: ${getCategoryColor(news.category)}">${news.category}</span>
                    <h3>${news.title}</h3>
                    <div class="news-meta">
                        <span>📅 ${news.date}</span>
                        <span>👁 ${news.views} ko'rish</span>
                    </div>
                    <p>${news.description}</p>
                    <a href="javascript:void(0)" class="read-more" onclick="event.stopPropagation(); showNewsDetails(${news.id})">Batafsil →</a>
                </div>
            </div>
        `).join('');
    }

    // Load news for news page
    const allNewsContainer = document.getElementById('allNewsContainer');
    if (allNewsContainer) {
        allNewsContainer.innerHTML = newsData.map(news => `
            <div class="news-card" onclick="showNewsDetails(${news.id})">
                <img src="${news.image}" alt="${news.title}">
                <div class="card-content">
                    <span class="news-category" style="background: ${getCategoryColor(news.category)}">${news.category}</span>
                    <h3>${news.title}</h3>
                    <div class="news-meta">
                        <span>📅 ${news.date}</span>
                        <span>👁 ${news.views} ko'rish</span>
                    </div>
                    <p>${news.description}</p>
                    <a href="javascript:void(0)" class="read-more" onclick="event.stopPropagation(); showNewsDetails(${news.id})">Batafsil →</a>
                </div>
            </div>
        `).join('');
    }
}

// Get category color
function getCategoryColor(category) {
    const colors = {
        'Fan': '#1e3c72',
        'Texnologiya': '#2a5298',
        'Sport': '#ff4757',
        'Madaniyat': '#ffa502',
        'Ta\'lim': '#7bed9f',
        'Loyiha': '#a55eea'
    };
    return colors[category] || '#1e3c72';
}

// Breaking news rotation
let currentNewsIndex = 0;
const breakingNewsElement = document.querySelector('#breakingNews p');

function rotateBreakingNews() {
    if (breakingNewsElement && breakingNews.length > 0) {
        currentNewsIndex = (currentNewsIndex + 1) % breakingNews.length;
        const news = breakingNews[currentNewsIndex];
        breakingNewsElement.innerHTML = `${news.icon} ${news.title}`;
    }
}

// Show all breaking news
function showAllBreakingNews() {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.9);
        backdrop-filter: blur(5px);
        z-index: 2000;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 20px;
    `;

    let newsHtml = breakingNews.map(news => `
        <div style="
            background: rgba(255,255,255,0.1);
            border-left: 4px solid ${categoryColors[news.category] || '#ff4757'};
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 0 8px 8px 0;
            color: white;
            cursor: pointer;
            transition: transform 0.3s;
        " onmouseover="this.style.transform='translateX(10px)'" onmouseout="this.style.transform='translateX(0)'">
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div style="flex: 1;">
                    <span style="font-size: 1.5rem; margin-right: 10px;">${news.icon}</span>
                    <strong>${news.title}</strong>
                    <p style="color: #ccc; margin-top: 5px; font-size: 0.9rem;">${news.description}</p>
                    <div style="display: flex; gap: 15px; margin-top: 8px; font-size: 0.8rem; color: #aaa;">
                        <span>📅 ${news.date}</span>
                        <span>⏰ ${news.time}</span>
                    </div>
                </div>
                <span style="background: ${categoryColors[news.category]}; padding: 3px 8px; border-radius: 5px; font-size: 0.7rem;">
                    ${categoryNames[news.category] || news.category}
                </span>
            </div>
        </div>
    `).join('');

    modal.innerHTML = `
        <div style="
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            max-width: 800px;
            width: 100%;
            max-height: 80vh;
            overflow-y: auto;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.5);
            position: relative;
        ">
            <button onclick="this.parentElement.parentElement.remove()" style="
                position: absolute;
                top: 20px;
                right: 20px;
                background: rgba(255,255,255,0.1);
                border: none;
                color: white;
                font-size: 1.5rem;
                cursor: pointer;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: background 0.3s;
            " onmouseover="this.style.background='rgba(255,255,255,0.2)'" onmouseout="this.style.background='rgba(255,255,255,0.1)'">×</button>

            <h2 style="color: white; margin-bottom: 20px;">📢 Barcha yangiliklar (${breakingNews.length} ta)</h2>

            <div style="margin-bottom: 20px;">
                <input type="text" placeholder="🔍 Yangiliklarni qidirish..." id="breakingNewsSearch"
                    style="
                        width: 100%;
                        padding: 12px;
                        border: none;
                        border-radius: 8px;
                        font-size: 1rem;
                        background: rgba(255,255,255,0.1);
                        color: white;
                        border: 2px solid transparent;
                    "
                    onkeyup="searchBreakingNews(this.value)"
                    onfocus="this.style.borderColor='#ff4757'"
                    onblur="this.style.borderColor='transparent'"
                >
            </div>

            <div id="breakingNewsList">
                ${newsHtml}
            </div>
        </div>
    `;

    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            document.body.removeChild(modal);
        }
    });

    document.body.appendChild(modal);
}

// Search breaking news
function searchBreakingNews(query) {
    const newsList = document.getElementById('breakingNewsList');
    if (!newsList) return;

    const filtered = breakingNews.filter(news =>
        news.title.toLowerCase().includes(query.toLowerCase()) ||
        news.description.toLowerCase().includes(query.toLowerCase())
    );

    if (filtered.length > 0) {
        newsList.innerHTML = filtered.map(news => `
            <div style="
                background: rgba(255,255,255,0.1);
                border-left: 4px solid ${categoryColors[news.category] || '#ff4757'};
                padding: 15px;
                margin-bottom: 10px;
                border-radius: 0 8px 8px 0;
                color: white;
            ">
                <div style="display: flex; justify-content: space-between;">
                    <div>
                        <span style="font-size: 1.5rem; margin-right: 10px;">${news.icon}</span>
                        <strong>${news.title}</strong>
                        <p style="color: #ccc; margin-top: 5px;">${news.description}</p>
                    </div>
                    <span style="background: ${categoryColors[news.category]}; padding: 3px 8px; border-radius: 5px; font-size: 0.7rem;">
                        ${categoryNames[news.category] || news.category}
                    </span>
                </div>
            </div>
        `).join('');
    } else {
        newsList.innerHTML = `
            <div style="text-align: center; color: white; padding: 50px;">
                <span style="font-size: 3rem;">😕</span>
                <p style="margin-top: 10px;">Hech narsa topilmadi</p>
            </div>
        `;
    }
}

// Show news details
function showNewsDetails(newsId) {
    const news = newsData.find(n => n.id === newsId);
    if (!news) return;

    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.9);
        backdrop-filter: blur(5px);
        z-index: 2000;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 20px;
    `;

    modal.innerHTML = `
        <div style="
            background: white;
            max-width: 800px;
            width: 100%;
            max-height: 80vh;
            overflow-y: auto;
            border-radius: 20px;
            padding: 30px;
            position: relative;
        ">
            <button onclick="this.parentElement.parentElement.remove()" style="
                position: absolute;
                top: 20px;
                right: 20px;
                background: #ff4757;
                border: none;
                color: white;
                font-size: 1.5rem;
                cursor: pointer;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
            ">×</button>

            <img src="${news.image}" alt="${news.title}" style="width: 100%; height: 300px; object-fit: cover; border-radius: 10px; margin-bottom: 20px;">

            <span style="background: ${getCategoryColor(news.category)}; color: white; padding: 5px 15px; border-radius: 25px; font-size: 0.9rem;">${news.category}</span>

            <h2 style="margin: 15px 0; color: #1e3c72;">${news.title}</h2>

            <div style="display: flex; gap: 20px; color: #666; margin-bottom: 20px;">
                <span>📅 ${news.date}</span>
                <span>👁 ${news.views} ko'rish</span>
                <span>✍️ ${news.author}</span>
            </div>

            <p style="line-height: 1.8; color: #333; font-size: 1.1rem;">${news.fullContent || news.description}</p>

            ${news.importance === 'high' ? '<p style="color: #ff4757; margin-top: 20px;">⭐ Muhim yangilik</p>' : ''}
        </div>
    `;

    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            document.body.removeChild(modal);
        }
    });

    document.body.appendChild(modal);
}

// Filter news by category
function filterNewsByCategory(category) {
    const filtered = newsData.filter(news => news.category === category);
    const newsContainer = document.getElementById('allNewsContainer');

    if (newsContainer) {
        if (filtered.length > 0) {
            newsContainer.innerHTML = filtered.map(news => `
                <div class="news-card" onclick="showNewsDetails(${news.id})">
                    <img src="${news.image}" alt="${news.title}">
                    <div class="card-content">
                        <span class="news-category" style="background: ${getCategoryColor(news.category)}">${news.category}</span>
                        <h3>${news.title}</h3>
                        <div class="news-meta">
                            <span>📅 ${news.date}</span>
                            <span>👁 ${news.views} ko'rish</span>
                        </div>
                        <p>${news.description}</p>
                        <a href="javascript:void(0)" class="read-more" onclick="event.stopPropagation(); showNewsDetails(${news.id})">Batafsil →</a>
                    </div>
                </div>
            `).join('');
        } else {
            newsContainer.innerHTML = '<p style="text-align: center; padding: 50px;">Bu kategoriyada yangiliklar yo\'q</p>';
        }
    }
}

// Navigation functionality
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.section');

    function showSection(sectionId) {
        sections.forEach(section => {
            section.classList.remove('active');
        });

        const selectedSection = document.getElementById(sectionId);
        if (selectedSection) {
            selectedSection.classList.add('active');
        }

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${sectionId}`) {
                link.classList.add('active');
            }
        });

        history.pushState(null, null, `#${sectionId}`);
    }

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const sectionId = link.getAttribute('href').substring(1);
            showSection(sectionId);
            document.querySelector('main').scrollIntoView({ behavior: 'smooth' });
        });
    });

    const hash = window.location.hash.substring(1);
    if (hash && document.getElementById(hash)) {
        showSection(hash);
    } else {
        showSection('home');
    }
}

// Footer links functionality
function setupFooterLinks() {
    const footerLinks = document.querySelectorAll('.footer-link');

    footerLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const sectionId = link.getAttribute('href').substring(1);
            const navLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);
            if (navLink) {
                navLink.click();
            }
        });
    });
}

// Contact form submission
function setupContactForm() {
    const contactForm = document.getElementById('contactForm');

    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();

            // Get form data
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const subject = formData.get('subject');
            const message = formData.get('message');

            // Show success message
            alert(`Rahmat, ${name || 'foydalanuvchi'}! Xabaringiz qabul qilindi. Tez orada siz bilan bog'lanamiz.`);

            // Reset form
            contactForm.reset();
        });
    }
}

// Gallery item click
function setupGallery() {
    const galleryItems = document.querySelectorAll('.gallery-item');

    galleryItems.forEach(item => {
        item.addEventListener('click', () => {
            const img = item.querySelector('img').src;
            const title = item.querySelector('.gallery-overlay p').textContent;

            const modal = document.createElement('div');
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.9);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 2000;
                cursor: pointer;
            `;

            modal.innerHTML = `
                <img src="${img}" alt="${title}" style="max-width: 90%; max-height: 90%; object-fit: contain;">
                <p style="position: absolute; bottom: 20px; left: 0; right: 0; text-align: center; color: white; font-size: 1.2rem;">${title}</p>
            `;

            modal.addEventListener('click', () => {
                document.body.removeChild(modal);
            });

            document.body.appendChild(modal);
        });
    });
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    loadNews();
    setupNavigation();
    setupFooterLinks();
    setupContactForm();
    setupGallery();

    // Start breaking news rotation
    setInterval(rotateBreakingNews, 5000);

    // Add click event to breaking news
    const breakingDiv = document.querySelector('.breaking-news');
    if (breakingDiv) {
        breakingDiv.style.cursor = 'pointer';
        breakingDiv.addEventListener('click', showAllBreakingNews);
    }

    // Add category filter buttons to news section
    const newsSection = document.getElementById('news');
    if (newsSection) {
        const categories = [...new Set(newsData.map(news => news.category))];
        const filterDiv = document.createElement('div');
        filterDiv.style.cssText = `
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        `;

        filterDiv.innerHTML = `
            <button onclick="filterNewsByCategory('all')" style="
                padding: 8px 16px;
                background: #1e3c72;
                color: white;
                border: none;
                border-radius: 25px;
                cursor: pointer;
            ">Barchasi</button>
            ${categories.map(cat => `
                <button onclick="filterNewsByCategory('${cat}')" style="
                    padding: 8px 16px;
                    background: ${getCategoryColor(cat)};
                    color: white;
                    border: none;
                    border-radius: 25px;
                    cursor: pointer;
                ">${cat}</button>
            `).join('')}
        `;

        newsSection.insertBefore(filterDiv, document.getElementById('allNewsContainer'));
    }
});

// Handle browser back/forward buttons
window.addEventListener('popstate', () => {
    const hash = window.location.hash.substring(1);
    if (hash && document.getElementById(hash)) {
        const navLink = document.querySelector(`.nav-link[href="#${hash}"]`);
        if (navLink) {
            navLink.click();
        }
    }
});

// Add 'all' filter option
window.filterNewsByCategory = function(category) {
    if (category === 'all') {
        loadNews();
    } else {
        filterNewsByCategory(category);
    }
};

// Login/Register Modal Functions
function openLoginModal() {
    document.getElementById('loginModal').style.display = 'block';
    closeRegisterModal();
}

function closeLoginModal() {
    document.getElementById('loginModal').style.display = 'none';
}

function openRegisterModal() {
    document.getElementById('registerModal').style.display = 'block';
    closeLoginModal();
}

function closeRegisterModal() {
    document.getElementById('registerModal').style.display = 'none';
}

function switchToRegister() {
    closeLoginModal();
    openRegisterModal();
}

function switchToLogin() {
    closeRegisterModal();
    openLoginModal();
}

// Handle Login
function handleLogin(event) {
    event.preventDefault();

    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    // Simple validation
    if (!email || !password) {
        alert('Iltimos, barcha maydonlarni to\'ldiring!');
        return;
    }

    // Here you would typically send this to a server
    console.log('Login attempt:', { email, password });

    // Show success message
    alert('Muvaffaqiyatli kirdingiz! Xush kelibsiz!');

    // Close modal
    closeLoginModal();

    // Update UI (optional - change login button to user name)
    const authButtons = document.querySelector('.auth-buttons');
    authButtons.innerHTML = '<span style="color: white; margin-right: 10px;">' + email.split('@')[0] + '</span><button class="auth-btn login-btn" onclick="logout()">Chiqish</button>';
}

// Handle Register
function handleRegister(event) {
    event.preventDefault();

    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('registerConfirmPassword').value;

    // Validation
    if (!name || !email || !password || !confirmPassword) {
        alert('Iltimos, barcha maydonlarni to\'ldiring!');
        return;
    }

    if (password.length < 6) {
        alert('Parol kamida 6 ta belgidan iborat bo\'lishi kerak!');
        return;
    }

    if (password !== confirmPassword) {
        alert('Parollar mos kelmadi!');
        return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Noto\'g\'ri email format!');
        return;
    }

    // Here you would typically send this to a server
    console.log('Register attempt:', { name, email, password });

    // Show success message
    alert('Ro\'yxatdan muvaffaqiyatli o\'tdingiz! Endi tizimga kirishingiz mumkin.');

    // Close register and open login
    closeRegisterModal();
    openLoginModal();
}

// Logout function
function logout() {
    if (confirm('Haqiqatan ham chiqmoqchimisiz?')) {
        // Restore original auth buttons
        const authButtons = document.querySelector('.auth-buttons');
        authButtons.innerHTML = `
            <button class="auth-btn login-btn" onclick="openLoginModal()">Kirish</button>
            <button class="auth-btn register-btn" onclick="openRegisterModal()">Ro'yxatdan o'tish</button>
        `;
        alert('Tizimdan chiqdingiz!');
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');

    if (event.target === loginModal) {
        closeLoginModal();
    }
    if (event.target === registerModal) {
        closeRegisterModal();
    }
}

// Add escape key support
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeLoginModal();
        closeRegisterModal();
    }
});

// Toggle password visibility
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = event.currentTarget;

    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Password strength checker
document.getElementById('registerPassword')?.addEventListener('input', function(e) {
    const password = e.target.value;
    const strengthBars = document.querySelectorAll('.strength-bar');
    const strengthText = document.querySelector('.strength-text');

    let strength = 0;

    if (password.length >= 6) strength++;
    if (password.match(/[a-z]+/)) strength++;
    if (password.match(/[A-Z]+/)) strength++;
    if (password.match(/[0-9]+/)) strength++;
    if (password.match(/[$@#&!]+/)) strength++;

    // Reset bars
    strengthBars.forEach(bar => bar.classList.remove('active'));

    // Set colors based on strength
    if (strength > 0) {
        for (let i = 0; i < Math.min(strength, 3); i++) {
            strengthBars[i].classList.add('active');
        }

        if (strength <= 2) {
            strengthText.textContent = 'Kuchsiz';
            strengthBars[0].style.background = '#ff4757';
        } else if (strength <= 4) {
            strengthText.textContent = 'O\'rtacha';
            strengthBars[0].style.background = '#ffa502';
            strengthBars[1].style.background = '#ffa502';
        } else {
            strengthText.textContent = 'Kuchli';
            strengthBars.forEach(bar => bar.style.background = '#7bed9f');
        }
    } else {
        strengthText.textContent = 'Parol kuchi';
    }
});