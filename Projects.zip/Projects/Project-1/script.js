        // AOS initialization
        AOS.init({
            duration: 1000,
            once: true,
            offset: 100
        });

        // Loader
        window.addEventListener('load', function() {
            setTimeout(function() {
                document.getElementById('loader').style.opacity = '0';
                setTimeout(function() {
                    document.getElementById('loader').style.display = 'none';
                }, 500);
            }, 1000);
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Mobile menu toggle
        function toggleMenu() {
            const navMenu = document.getElementById('navMenu');
            navMenu.classList.toggle('active');
        }

        // Resize event - mobile menu yopish
        window.addEventListener('resize', function() {
            const navMenu = document.getElementById('navMenu');
            if (window.innerWidth > 850) {
                navMenu.classList.remove('active');
            }
        });

        // Dars jadvallari (1-11 sinflar uchun)
        const schedules = {
            1: {
                monday: ['Matematika', 'Ona tili', 'Rasm', 'Musiqa'],
                tuesday: ['O\'qish', 'Atrofimizdagi olam', 'Jismoniy tarbiya', 'Ingliz tili'],
                wednesday: ['Matematika', 'Ona tili', 'Texnologiya', 'Qo\'shiq'],
                thursday: ['O\'qish', 'Matematika', 'Jismoniy tarbiya', 'Rasm'],
                friday: ['Ona tili', 'Atrofimizdagi olam', 'Musiqa', 'Ingliz tili'],
                saturday: ['Matematika', 'O\'qish', 'Texnologiya', 'Jismoniy tarbiya']
            },
            2: {
                monday: ['Matematika', 'Ona tili', 'Ingliz tili', 'Jismoniy tarbiya'],
                tuesday: ['O\'qish', 'Atrofimizdagi olam', 'Musiqa', 'Rasm'],
                wednesday: ['Matematika', 'Ona tili', 'Texnologiya', 'Ingliz tili'],
                thursday: ['O\'qish', 'Matematika', 'Jismoniy tarbiya', 'Musiqa'],
                friday: ['Ona tili', 'Atrofimizdagi olam', 'Ingliz tili', 'Rasm'],
                saturday: ['Matematika', 'O\'qish', 'Texnologiya', 'Jismoniy tarbiya']
            },
            3: {
                monday: ['Matematika', 'Ona tili', 'Ingliz tili', 'Tarix'],
                tuesday: ['O\'qish', 'Tabiat', 'Musiqa', 'Jismoniy tarbiya'],
                wednesday: ['Matematika', 'Ona tili', 'Ingliz tili', 'Rasm'],
                thursday: ['O\'qish', 'Matematika', 'Tabiat', 'Texnologiya'],
                friday: ['Ona tili', 'Ingliz tili', 'Musiqa', 'Jismoniy tarbiya'],
                saturday: ['Matematika', 'O\'qish', 'Tarix', 'Rasm']
            },
            4: {
                monday: ['Matematika', 'Ona tili', 'Ingliz tili', 'Tarix', 'Jismoniy tarbiya'],
                tuesday: ['O\'qish', 'Tabiat', 'Musiqa', 'Rasm', 'Texnologiya'],
                wednesday: ['Matematika', 'Ona tili', 'Ingliz tili', 'Geografiya', 'Jismoniy tarbiya'],
                thursday: ['O\'qish', 'Matematika', 'Tabiat', 'Tarix', 'Ingliz tili'],
                friday: ['Ona tili', 'Ingliz tili', 'Musiqa', 'Geografiya', 'Jismoniy tarbiya'],
                saturday: ['Matematika', 'O\'qish', 'Tarix', 'Rasm', 'Texnologiya']
            },
            5: {
                monday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Tarix', 'Fizika'],
                tuesday: ['Geometriya', 'Biologiya', 'Kimyo', 'Jismoniy tarbiya', 'Informatika'],
                wednesday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Geografiya', 'Texnologiya'],
                thursday: ['Geometriya', 'Fizika', 'Tarix', 'Biologiya', 'Ingliz tili'],
                friday: ['Algebra', 'Adabiyot', 'Kimyo', 'Informatika', 'Jismoniy tarbiya'],
                saturday: ['Geometriya', 'Biologiya', 'Fizika', 'Ingliz tili', 'Tarix']
            },
            6: {
                monday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Tarix'],
                tuesday: ['Geometriya', 'Biologiya', 'Kimyo', 'Informatika', 'Jismoniy tarbiya'],
                wednesday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Geografiya', 'Texnologiya'],
                thursday: ['Geometriya', 'Fizika', 'Kimyo', 'Biologiya', 'Ingliz tili'],
                friday: ['Algebra', 'Adabiyot', 'Tarix', 'Informatika', 'Jismoniy tarbiya'],
                saturday: ['Geometriya', 'Fizika', 'Biologiya', 'Ingliz tili', 'Tarix']
            },
            7: {
                monday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Tarix', 'Geografiya'],
                tuesday: ['Geometriya', 'Biologiya', 'Kimyo', 'Informatika', 'Jismoniy tarbiya', 'Musiqa'],
                wednesday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Texnologiya', 'Rasm'],
                thursday: ['Geometriya', 'Biologiya', 'Kimyo', 'Tarix', 'Ingliz tili', 'Jismoniy tarbiya'],
                friday: ['Algebra', 'Adabiyot', 'Fizika', 'Informatika', 'Geografiya', 'Jismoniy tarbiya'],
                saturday: ['Geometriya', 'Biologiya', 'Kimyo', 'Ingliz tili', 'Tarix', 'Texnologiya']
            },
            8: {
                monday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Tarix', 'Geografiya'],
                tuesday: ['Geometriya', 'Biologiya', 'Kimyo', 'Informatika', 'Jismoniy tarbiya', 'Musiqa'],
                wednesday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Texnologiya', 'Rasm'],
                thursday: ['Geometriya', 'Biologiya', 'Kimyo', 'Tarix', 'Ingliz tili', 'Jismoniy tarbiya'],
                friday: ['Algebra', 'Adabiyot', 'Fizika', 'Informatika', 'Geografiya', 'Jismoniy tarbiya'],
                saturday: ['Geometriya', 'Biologiya', 'Kimyo', 'Ingliz tili', 'Tarix', 'Texnologiya']
            },
            9: {
                monday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Tarix', 'Geografiya', 'Biologiya'],
                tuesday: ['Geometriya', 'O\'zbek tili', 'Kimyo', 'Informatika', 'Jismoniy tarbiya', 'Musiqa', 'Rasm'],
                wednesday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Texnologiya', 'Tarix', 'Geometriya'],
                thursday: ['Geometriya', 'Biologiya', 'Kimyo', 'Tarix', 'Ingliz tili', 'Jismoniy tarbiya', 'Algebra'],
                friday: ['Algebra', 'Adabiyot', 'Fizika', 'Informatika', 'Geografiya', 'Jismoniy tarbiya', 'Biologiya'],
                saturday: ['Geometriya', 'Biologiya', 'Kimyo', 'Ingliz tili', 'Tarix', 'Texnologiya', 'Algebra']
            },
            10: {
                monday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Tarix', 'Geografiya', 'Biologiya'],
                tuesday: ['Geometriya', 'O\'zbek tili', 'Kimyo', 'Informatika', 'Jismoniy tarbiya', 'Musiqa', 'Rasm'],
                wednesday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Texnologiya', 'Tarix', 'Geometriya'],
                thursday: ['Geometriya', 'Biologiya', 'Kimyo', 'Tarix', 'Ingliz tili', 'Jismoniy tarbiya', 'Algebra'],
                friday: ['Algebra', 'Adabiyot', 'Fizika', 'Informatika', 'Geografiya', 'Jismoniy tarbiya', 'Biologiya'],
                saturday: ['Geometriya', 'Biologiya', 'Kimyo', 'Ingliz tili', 'Tarix', 'Texnologiya', 'Algebra']
            },
            11: {
                monday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Tarix', 'Geografiya', 'Biologiya'],
                tuesday: ['Geometriya', 'O\'zbek tili', 'Kimyo', 'Informatika', 'Jismoniy tarbiya', 'Musiqa', 'Rasm'],
                wednesday: ['Algebra', 'Adabiyot', 'Ingliz tili', 'Fizika', 'Texnologiya', 'Tarix', 'Geometriya'],
                thursday: ['Geometriya', 'Biologiya', 'Kimyo', 'Tarix', 'Ingliz tili', 'Jismoniy tarbiya', 'Algebra'],
                friday: ['Algebra', 'Adabiyot', 'Fizika', 'Informatika', 'Geografiya', 'Jismoniy tarbiya', 'Biologiya'],
                saturday: ['Geometriya', 'Biologiya', 'Kimyo', 'Ingliz tili', 'Tarix', 'Texnologiya', 'Algebra']
            }
        };

        // Modal functions
        function showModal(type) {
            document.getElementById(type + 'Modal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }

        function hideModal(type) {
            document.getElementById(type + 'Modal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        // Close modal on outside click
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }

        // Login handler
        function handleLogin(event) {
            event.preventDefault();

            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;

            const users = JSON.parse(localStorage.getItem('users')) || [];
            const user = users.find(u => u.email === email && u.password === password);

            if (user) {
                localStorage.setItem('currentUser', JSON.stringify(user));
                hideModal('login');
                showDashboard(user);
                showNotification('Xush kelibsiz, ' + user.name + '!', 'success');
            } else {
                showNotification('Email yoki parol noto\'g\'ri!', 'error');
            }
        }

        // Register handler
        function handleRegister(event) {
            event.preventDefault();

            const name = document.getElementById('regName').value;
            const email = document.getElementById('regEmail').value;
            const className = document.getElementById('regClass').value;
            const password = document.getElementById('regPassword').value;
            const confirmPassword = document.getElementById('regConfirmPassword').value;

            if (password !== confirmPassword) {
                showNotification('Parollar mos kelmadi!', 'error');
                return;
            }

            const users = JSON.parse(localStorage.getItem('users')) || [];

            if (users.some(u => u.email === email)) {
                showNotification('Bu email allaqachon ro\'yxatdan o\'tgan!', 'error');
                return;
            }

            const newUser = {
                name,
                email,
                class: className,
                password
            };

            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users));

            showNotification('Ro\'yxatdan o\'tish muvaffaqiyatli!', 'success');
            hideModal('register');
            showModal('login');
        }

        // Dashboard show
        function showDashboard(user) {
            document.getElementById('publicContent').style.display = 'none';
            document.getElementById('dashboard').style.display = 'block';

            document.getElementById('userName').textContent = user.name;

            let className = '';
            switch(user.class) {
                case '1': className = '1-sinf'; break;
                case '2': className = '2-sinf'; break;
                case '3': className = '3-sinf'; break;
                case '4': className = '4-sinf'; break;
                case '5': className = '5-sinf'; break;
                case '6': className = '6-sinf'; break;
                case '7': className = '7-sinf'; break;
                case '8': className = '8-sinf'; break;
                case '9': className = '9-sinf'; break;
                case '10': className = '10-sinf'; break;
                case '11': className = '11-sinf'; break;
            }
            document.getElementById('userClassText').innerHTML = `Sinf: ${className} | ID: 2024${user.class}${Math.floor(Math.random() * 100)}`;

            // Dashboard jadvalini yuklash
            loadDashboardSchedule(user.class);
        }

        // Load dashboard schedule
        function loadDashboardSchedule(className) {
            const schedule = schedules[className];
            if (!schedule) return;

            // Dushanba jadvalini ko'rsatish
            updateScheduleDisplay('monday', schedule);
        }

        // Change schedule day
        function changeScheduleDay(day) {
            const tabs = document.querySelectorAll('.schedule-tab');
            tabs.forEach(tab => tab.classList.remove('active'));
            event.target.classList.add('active');

            const user = JSON.parse(localStorage.getItem('currentUser'));
            if (user) {
                const schedule = schedules[user.class];
                updateScheduleDisplay(day, schedule);
            }
        }

        // Update schedule display
        function updateScheduleDisplay(day, schedule) {
            const container = document.getElementById('scheduleContent');
            const lessons = schedule[day];

            if (!lessons) return;

            let html = '';
            const dayNames = {
                monday: 'Dushanba',
                tuesday: 'Seshanba',
                wednesday: 'Chorshanba',
                thursday: 'Payshanba',
                friday: 'Juma',
                saturday: 'Shanba'
            };

            html += `
                <div class="schedule-day">
                    <div class="day-header">
                        <h4>${dayNames[day]}</h4>
                    </div>
                    <ul class="day-lessons">
            `;

            lessons.forEach((lesson, index) => {
                html += `
                    <li>
                        <span class="lesson-time">${index + 1}-dars (${9 + index}:00)</span>
                        <span class="lesson-name">${lesson}</span>
                    </li>
                `;
            });

            html += '</ul></div>';
            container.innerHTML = html;
        }

        // Logout
        function logout() {
            localStorage.removeItem('currentUser');
            document.getElementById('publicContent').style.display = 'block';
            document.getElementById('dashboard').style.display = 'none';
            showNotification('Tizimdan chiqildi!', 'info');
        }

        // Contact form
        function handleContact(event) {
            event.preventDefault();
            showNotification('Xabaringiz yuborildi! Tez orada javob beramiz.', 'success');
            event.target.reset();
        }

        // Notification
        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = 'notification';
            notification.style.background = type === 'success' ? 'linear-gradient(135deg, #28a745 0%, #20c997 100%)' :
                                           type === 'error' ? 'linear-gradient(135deg, #dc3545 0%, #f00 100%)' :
                                           'linear-gradient(135deg, #17a2b8 0%, #0dcaf0 100%)';
            notification.textContent = message;

            document.body.appendChild(notification);

            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, 3000);
        }

        // Check login status on load
        document.addEventListener('DOMContentLoaded', () => {
            const currentUser = JSON.parse(localStorage.getItem('currentUser'));
            if (currentUser) {
                showDashboard(currentUser);
            }
        });

        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });

                    // Mobile menyuni yopish
                    const navMenu = document.getElementById('navMenu');
                    navMenu.classList.remove('active');
                }
            });
        });