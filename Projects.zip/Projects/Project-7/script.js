// Calendar state
        let currentDate = new Date();
        let currentView = 'month';
        let events = [];

        // Load events from localStorage
        function loadEvents() {
            const savedEvents = localStorage.getItem('schoolEvents');
            if (savedEvents) {
                events = JSON.parse(savedEvents);
            } else {
                // Sample events for Fevral 2026
                events = [
                    {
                        id: 1,
                        title: "Matematika olimpiadasi",
                        date: "2026-02-10",
                        time: "10:00",
                        category: "academic",
                        description: "Maktab ichki matematika olimpiadasi",
                        location: "211-xona"
                    },
                    {
                        id: 2,
                        title: "Voleybol turniri",
                        date: "2026-02-15",
                        time: "14:00",
                        category: "sport",
                        description: "Sinf jamoalari o'rtasida voleybol musobaqasi",
                        location: "Sport zal"
                    },
                    {
                        id: 3,
                        title: "Navro'z bayrami",
                        date: "2026-03-21",
                        time: "11:00",
                        category: "cultural",
                        description: "Navro'z bayramiga bag'ishlangan tadbir",
                        location: "Aktlar zali"
                    },
                    {
                        id: 4,
                        title: "Ochiq eshiklar kuni",
                        date: "2026-02-20",
                        time: "10:00",
                        category: "meeting",
                        description: "Ota-onalar uchun ochiq eshiklar kuni",
                        location: "Maktab binosi"
                    }
                ];
            }
            updateEventsList();
        }

        // Save events to localStorage
        function saveEvents() {
            localStorage.setItem('schoolEvents', JSON.stringify(events));
        }

        // Get month name
        function getMonthName(month) {
            const months = [
                'Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'Iyun',
                'Iyul', 'Avgust', 'Sentyabr', 'Oktyabr', 'Noyabr', 'Dekabr'
            ];
            return months[month];
        }

        // Update current date display
        function updateCurrentDate() {
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent =
                new Date().toLocaleDateString('uz-UZ', options);
        }

        // Render calendar
        function renderCalendar() {
            const year = currentDate.getFullYear();
            const month = currentDate.getMonth();

            document.getElementById('monthYear').textContent =
                `${getMonthName(month)} ${year}`;

            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);

            let firstDayIndex = firstDay.getDay();
            firstDayIndex = firstDayIndex === 0 ? 6 : firstDayIndex - 1;

            const lastDate = lastDay.getDate();
            const prevLastDay = new Date(year, month, 0);
            const prevLastDate = prevLastDay.getDate();

            const nextDays = 7 - ((lastDate + firstDayIndex) % 7);

            // Week days
            const weekDays = ['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya'];
            document.getElementById('weekDays').innerHTML = weekDays.map(day =>
                `<span class="week-day">${day}</span>`
            ).join('');

            let calendarHtml = '';

            // Previous month days
            for (let x = firstDayIndex; x > 0; x--) {
                calendarHtml += createDayElement(prevLastDate - x + 1, true);
            }

            // Current month days
            for (let i = 1; i <= lastDate; i++) {
                const isToday = i === new Date().getDate() &&
                                month === new Date().getMonth() &&
                                year === new Date().getFullYear();
                calendarHtml += createDayElement(i, false, isToday);
            }

            // Next month days
            for (let j = 1; j <= nextDays; j++) {
                calendarHtml += createDayElement(j, true);
            }

            document.getElementById('calendar').innerHTML = calendarHtml;
        }

        // Create day element
        function createDayElement(day, isOtherMonth, isToday = false) {
            const year = currentDate.getFullYear();
            const month = currentDate.getMonth();

            let dateStr;
            if (isOtherMonth) {
                if (day > 20) { // Oldingi oy
                    dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                } else { // Keyingi oy
                    dateStr = `${year}-${String(month + 2).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                }
            } else {
                dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            }

            const dayEvents = events.filter(event => event.date === dateStr);

            const eventPreviews = dayEvents.slice(0, 2).map(event =>
                `<div class="event-preview">
                    <span class="event-indicator"></span>
                    ${event.title.substring(0, 10)}...
                </div>`
            ).join('');

            const classes = ['calendar-day'];
            if (isOtherMonth) classes.push('other-month');
            if (isToday) classes.push('today');

            return `
                <div class="${classes.join(' ')}" onclick="showDayEvents('${dateStr}')">
                    <div class="day-number">${day}</div>
                    ${eventPreviews}
                    ${dayEvents.length > 2 ? `<div class="event-preview">+${dayEvents.length - 2}</div>` : ''}
                </div>
            `;
        }

        // Change month
        function changeMonth(delta) {
            currentDate.setMonth(currentDate.getMonth() + delta);
            renderCalendar();
        }

        // Change view
        function changeView(view) {
            currentView = view;
            document.querySelectorAll('.view-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');

            if (view === 'month') {
                renderCalendar();
            } else if (view === 'week') {
                alert('Haftalik ko\'rinish ishlab chiqilmoqda');
            } else if (view === 'day') {
                alert('Kunlik ko\'rinish ishlab chiqilmoqda');
            }
        }

        // Update events list
        function updateEventsList() {
            const sortedEvents = [...events].sort((a, b) => new Date(a.date) - new Date(b.date));
            const today = new Date();
            const upcomingEvents = sortedEvents.filter(event => new Date(event.date) >= today);

            const eventsList = document.getElementById('eventsList');

            if (upcomingEvents.length === 0) {
                eventsList.innerHTML = '<div style="color: white; text-align: center; padding: 20px;">Kelgusi tadbirlar mavjud emas</div>';
                return;
            }

            eventsList.innerHTML = upcomingEvents.map(event => {
                const date = new Date(event.date);
                const monthNames = ['Yan', 'Fev', 'Mar', 'Apr', 'May', 'Iyun', 'Iyul', 'Avg', 'Sen', 'Okt', 'Noy', 'Dek'];

                return `
                    <div class="event-card">
                        <div class="event-date">
                            <span class="day">${date.getDate()}</span>
                            <span class="month">${monthNames[date.getMonth()]}</span>
                        </div>
                        <div class="event-details">
                            <h4>
                                ${event.title}
                                <span class="event-category category-${event.category}">
                                    ${getCategoryName(event.category)}
                                </span>
                            </h4>
                            <p>${event.description}</p>
                            <div class="event-time">
                                <span>⏰ ${event.time}</span>
                                <span>📍 ${event.location}</span>
                            </div>
                        </div>
                        <button class="delete-btn" onclick="deleteEvent(${event.id})">🗑️</button>
                    </div>
                `;
            }).join('');
        }

        // Get category name
        function getCategoryName(category) {
            const categories = {
                sport: 'Sport',
                academic: 'O\'quv',
                cultural: 'Madaniy',
                meeting: 'Yig\'ilish'
            };
            return categories[category] || category;
        }

        // Show day events
        function showDayEvents(dateStr) {
            const dayEvents = events.filter(event => event.date === dateStr);
            const date = new Date(dateStr);
            const day = date.getDate();
            const month = getMonthName(date.getMonth());

            if (dayEvents.length > 0) {
                let message = `${day} ${month} kunidagi tadbirlar:\n\n`;
                dayEvents.forEach(e => {
                    message += `• ${e.time} - ${e.title} (${e.location})\n`;
                });
                alert(message);
            } else {
                if (confirm(`${day} ${month} kuniga tadbir qo'shilsinmi?`)) {
                    openModal(dateStr);
                }
            }
        }

        // Modal functions
        function openModal(selectedDate = null) {
            document.getElementById('eventModal').classList.add('active');
            if (selectedDate) {
                document.getElementById('eventDate').value = selectedDate;
            }
        }

        function closeModal() {
            document.getElementById('eventModal').classList.remove('active');
            document.getElementById('eventForm').reset();
        }

        // Add event
        function addEvent(e) {
            e.preventDefault();

            const newEvent = {
                id: Date.now(),
                title: document.getElementById('eventTitle').value,
                date: document.getElementById('eventDate').value,
                time: document.getElementById('eventTime').value,
                category: document.getElementById('eventCategory').value,
                description: document.getElementById('eventDescription').value,
                location: document.getElementById('eventLocation').value
            };

            events.push(newEvent);
            saveEvents();
            renderCalendar();
            updateEventsList();
            closeModal();
        }

        // Delete event
        function deleteEvent(id) {
            if (confirm('Tadbirni o\'chirishni tasdiqlaysizmi?')) {
                events = events.filter(event => event.id !== id);
                saveEvents();
                renderCalendar();
                updateEventsList();
            }
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', () => {
            // MART 2026 ni o'rnatish
            currentDate = new Date(2026, 2, 1); // 2 - Mart

            // Agar JORIY OY (bugun) kerak bo'lsa:
            // currentDate = new Date();

            updateCurrentDate();
            loadEvents();
            renderCalendar();
            setInterval(updateCurrentDate, 1000);
            checkSavedUser();
        });

            // ========== AUTH STATE ==========
        let currentUser = null;

        // Modal functions
        function openLoginModal() {
            document.getElementById('loginModal').classList.add('active');
        }

        function closeLoginModal() {
            document.getElementById('loginModal').classList.remove('active');
            document.getElementById('loginForm').reset();
        }

        function openRegisterModal() {
            document.getElementById('registerModal').classList.add('active');
        }

        function closeRegisterModal() {
            document.getElementById('registerModal').classList.remove('active');
            document.getElementById('registerForm').reset();
            document.getElementById('passwordMatch').innerHTML = '';
        }

        function switchToLogin() {
            closeRegisterModal();
            openLoginModal();
        }

        function switchToRegister() {
            closeLoginModal();
            openRegisterModal();
        }

        // Toggle password visibility
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const type = input.type === 'password' ? 'text' : 'password';
            input.type = type;
        }

        // Password strength checker
        document.getElementById('regPassword')?.addEventListener('input', function(e) {
            const password = e.target.value;
            const bars = document.querySelectorAll('.strength-bar');
            let strength = 0;

            if (password.length >= 8) strength++;
            if (password.length >= 10) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[!@#$%^&*]/.test(password)) strength++;

            bars.forEach((bar, index) => {
                if (index < strength) {
                    bar.classList.add('active');
                } else {
                    bar.classList.remove('active');
                }
            });
        });

        // Password match checker
        document.getElementById('regConfirmPassword')?.addEventListener('input', function(e) {
            const password = document.getElementById('regPassword').value;
            const confirm = e.target.value;
            const matchDiv = document.getElementById('passwordMatch');

            if (confirm.length === 0) {
                matchDiv.innerHTML = '';
            } else if (password === confirm) {
                matchDiv.innerHTML = '✓ Parollar mos keldi';
                matchDiv.style.color = '#7bed9f';
            } else {
                matchDiv.innerHTML = '✗ Parollar mos kelmadi';
                matchDiv.style.color = '#ff4757';
            }
        });

        // LOGIN FUNCTION - Tizimga kirish
        function loginUser(e) {
            e.preventDefault();

            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            const remember = document.getElementById('rememberMe').checked;

            // Get users from localStorage
            const users = JSON.parse(localStorage.getItem('users') || '[]');

            // Find user
            const user = users.find(u => u.email === email && u.password === password);

            if (user) {
                // Save current user
                currentUser = user;

                if (remember) {
                    localStorage.setItem('currentUser', JSON.stringify(user));
                } else {
                    sessionStorage.setItem('currentUser', JSON.stringify(user));
                }

                // Update UI
                updateUIAfterLogin(user);

                // Show success message
                showSuccessMessage(`✅ Xush kelibsiz, ${user.firstName}!`);

                // Close modal
                closeLoginModal();
            } else {
                alert('❌ Email yoki parol noto\'g\'ri!');
            }
        }

        // REGISTER FUNCTION - Ro'yxatdan o'tish
        function registerUser(e) {
            e.preventDefault();

            const firstName = document.getElementById('regFirstName').value;
            const lastName = document.getElementById('regLastName').value;
            const email = document.getElementById('regEmail').value;
            const phone = document.getElementById('regPhone').value;
            const password = document.getElementById('regPassword').value;
            const confirm = document.getElementById('regConfirmPassword').value;

            // Validations
            if (password !== confirm) {
                alert('❌ Parollar mos kelmadi!');
                return;
            }

            if (password.length < 6) {
                alert('❌ Parol kamida 6 belgi bo\'lishi kerak!');
                return;
            }

            // Get existing users
            const users = JSON.parse(localStorage.getItem('users') || '[]');

            // Check if email exists
            if (users.some(u => u.email === email)) {
                alert('❌ Bu email allaqachon ro\'yxatdan o\'tgan!');
                return;
            }

            // Create new user
            const newUser = {
                id: Date.now(),
                firstName,
                lastName,
                email,
                phone,
                password,
                avatar: '👤'
            };

            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users));

            // Auto login after registration
            currentUser = newUser;
            sessionStorage.setItem('currentUser', JSON.stringify(newUser));

            // Update UI
            updateUIAfterLogin(newUser);

            // Show success message
            showSuccessMessage(`✅ Ro'yxatdan o'tdingiz! Xush kelibsiz, ${firstName}!`);

            // Close modal
            closeRegisterModal();
        }

        // LOGOUT FUNCTION - Tizimdan chiqish
        function logoutUser() {
            // Clear user data
            currentUser = null;
            localStorage.removeItem('currentUser');
            sessionStorage.removeItem('currentUser');

            // Update UI
            document.getElementById('authButtons').style.display = 'flex';
            document.getElementById('userProfile').style.display = 'none';

            // Hide profile menu
            document.getElementById('profileMenu').classList.remove('show');

            // Show message
            showSuccessMessage('👋 Tizimdan chiqdingiz');
        }

        // Update UI after login
        function updateUIAfterLogin(user) {
            // Hide login/register buttons
            document.getElementById('authButtons').style.display = 'none';

            // Show user profile
            document.getElementById('userProfile').style.display = 'block';

            // Update user info
            document.getElementById('userName').textContent = `${user.firstName} ${user.lastName}`;
            document.getElementById('userEmail').textContent = user.email;

            // Random avatar (1,2,3,4)
            const avatars = ['👤', '👨', '👩', '🧑', '👱', '👴', '👵'];
            const randomAvatar = avatars[Math.floor(Math.random() * avatars.length)];
            document.getElementById('userAvatar').textContent = randomAvatar;
        }

        // Toggle profile menu
        function toggleProfileMenu() {
            document.getElementById('profileMenu').classList.toggle('show');
        }

        // Close profile menu when clicking outside
        document.addEventListener('click', function(event) {
            const profile = document.querySelector('.user-profile');
            const menu = document.getElementById('profileMenu');

            if (profile && !profile.contains(event.target) && menu.classList.contains('show')) {
                menu.classList.remove('show');
            }
        });

        // Show success message
        function showSuccessMessage(message) {
            const msgDiv = document.createElement('div');
            msgDiv.className = 'success-message';
            msgDiv.textContent = message;
            document.body.appendChild(msgDiv);

            setTimeout(() => {
                msgDiv.remove();
            }, 3000);
        }

        // Profile functions
        function showMyEvents() {
            if (!currentUser) return;

            const userEvents = JSON.parse(localStorage.getItem('events') || '[]')
                .filter(event => event.createdBy === currentUser.id);

            if (userEvents.length === 0) {
                showSuccessMessage('📭 Siz hali tadbir qo\'shmagansiz');
            } else {
                let message = '📅 Sizning tadbirlaringiz:\n';
                userEvents.forEach(e => message += `\n• ${e.title} (${e.date})`);
                alert(message);
            }

            document.getElementById('profileMenu').classList.remove('show');
        }

        function showProfile() {
            if (!currentUser) return;

            alert(`👤 Foydalanuvchi ma'lumotlari:

        Ism: ${currentUser.firstName} ${currentUser.lastName}
        Email: ${currentUser.email}
        Telefon: ${currentUser.phone || "Ko'rsatilmagan"}
        ID: ${currentUser.id}`);

            document.getElementById('profileMenu').classList.remove('show');
        }

        // Check saved user on page load
        function checkSavedUser() {
            const savedUser = JSON.parse(localStorage.getItem('currentUser') || sessionStorage.getItem('currentUser') || 'null');

            if (savedUser) {
                currentUser = savedUser;
                updateUIAfterLogin(savedUser);
            }
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', () => {
            checkSavedUser();
            updateCurrentDate();
            setInterval(updateCurrentDate, 1000);
        });

        // Update current date
        function updateCurrentDate() {
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.getElementById('currentDate').textContent =
                new Date().toLocaleDateString('uz-UZ', options);
        }