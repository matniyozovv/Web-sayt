// Kitoblar ma'lumotlari (JSON formatda) - To'liq yangilangan
const booksData = {
    featured: [
        {
            id: 1,
            title: "Dunyo tarixi",
            author: "Yuval Noah Harari",
            description: "Insoniyatning qisqa tarixi kitobining davomi bo'lgan asar, zamonaviy jamiyatning asosiy muammolari va kelajakdagi istiqbollari haqida.",
            category: "history",
            year: 2018,
            pages: 512,
            rating: 4.7,
            coverColor: "#3498db",
            tags: ["tarix", "jamiyat", "falsafa"],
            imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8jqjOvRF-3cZw_RwFuDwmqB31usB7c1e8Bg&s"
        },
        {
            id: 2,
            title: "Kechirim",
            author: "Elif Shafak",
            description: "Turkiyalik mashhur yozuvchi Elif Shafakning eng yaxshi romanlaridan biri. Sevgi, sadoqat va kechirim mavzulariga bag'ishlangan.",
            category: "fiction",
            year: 2020,
            pages: 356,
            rating: 4.5,
            coverColor: "#e74c3c",
            tags: ["roman", "drama", "sevgi"],
            imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5h2GfX6eviKiRQL1iv_fqFieHMOlSI9prag&s"
        },
        {
            id: 3,
            title: "Sun'iy intellekt asoslari",
            author: "Stuart Russell",
            description: "Sun'iy intellektning nazariy va amaliy asoslarini o'rganish uchun eng yaxshi qo'llanma. Muhandislar va dasturchilar uchun.",
            category: "technology",
            year: 2021,
            pages: 720,
            rating: 4.8,
            coverColor: "#2c3e50",
            tags: ["texnologiya", "AI", "dasturlash"],
            imageUrl: "https://assets.asaxiy.uz/product/items/desktop/05cb0c82cd7d107b795e057fcb164eb92022012910570097589VBOmKLtuED.jpg.webp "
        },
        {
            id: 4,
            title: "O'zbekiston tarixi",
            author: "Ahmad Aliy",
            description: "Qadimgi davrlardan to hozirgi kungacha O'zbekiston tarixini qamrab olgan keng qamrovli asar.",
            category: "history",
            year: 2019,
            pages: 480,
            rating: 4.6,
            coverColor: "#27ae60",
            tags: ["tarix", "o'zbekiston", "madaniyat"],
            imageUrl: "https://imgv2-1-f.scribdassets.com/img/document/840731744/original/6529b23d74/1?v=1"
        },
        {
            id: 5,
            title: "Dasturlash sirlari",
            author: "Robert Martin",
            description: "Toza kod yozish va dasturlashning eng yaxshi usullari haqida jahon miqyosidagi bestseller.",
            category: "technology",
            year: 2022,
            pages: 432,
            rating: 4.9,
            coverColor: "#8e44ad",
            tags: ["dasturlash", "kod", "software"],
            imageUrl: "https://assets.asaxiy.uz/product/items/desktop/5be011913a3755283e9cbc3f3274392a2020122213484683032kh21VvDwZY.jpg.webp"
        },
        {
            id: 6,
            title: "Jonli tabiat",
            author: "Karl Sagan",
            description: "Koinot, hayot va inson aqlining mo'jizalariga bag'ishlangan ilmiy-populyar asar.",
            category: "science",
            year: 2017,
            pages: 396,
            rating: 4.8,
            coverColor: "#16a085",
            tags: ["fan", "koinot", "falsafa"],
            imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGGrsuhyAURsq0aATpyRob6R7IAveJ1G_cDw&s"
        }
    ],
    new: [
        {
            id: 7,
            title: "Metaverse kelajagi",
            author: "Matthew Ball",
            description: "Virtual dunyolar va internetning yangi avlodining kelajagi haqida eng so'nggi tadqiqotlar.",
            category: "technology",
            year: 2023,
            pages: 320,
            rating: 4.6,
            coverColor: "#e67e22",
            tags: ["metaverse", "virtual", "texnologiya"],
            imageUrl: "https://alldata.uz/wp-content/uploads/2024/11/Metaverse-Kelajakdagi-Virtual-Dunyo_001.jpg"
        },
        {
            id: 8,
            title: "Million dollarlik startap",
            author: "Peter Thiel",
            description: "Muvaffaqiyatli startap yaratish va biznesni rivojlantirish bo'yicha amaliy maslahatlar.",
            category: "technology",
            year: 2023,
            pages: 280,
            rating: 4.7,
            coverColor: "#c0392b",
            tags: ["biznes", "startap", "moliya"],
            imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnqF_4n21d1LHAScplIkzZzx8Cy7ftiCrT1g&s"
        },
        {
            id: 9,
            title: "Ikkinchi hayot",
            author: "Munisa Shuxratova",
            description: "Yosh yozuvchining birinchi romani. Yoshligingizni qanday yashashingiz kerakligi haqida.",
            category: "fiction",
            year: 2023,
            pages: 245,
            rating: 4.4,
            coverColor: "#2980b9",
            tags: ["roman", "yosh", "hayot"],
            imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ38Yo5UFYdcSFCtXa_H-awaYrZ5nYvDNiX1g&s"
        },
        {
            id: 10,
            title: "Kvant fizikasi",
            author: "Brian Greene",
            description: "Kvant fizikasining asosiy tushunchalarini oddiy tilda tushuntirib beradigan asar.",
            category: "science",
            year: 2023,
            pages: 410,
            rating: 4.8,
            coverColor: "#7f8c8d",
            tags: ["fizika", "kvant", "ilm"],
            imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOdelBi0f7NRsChKRBXk01lzP7xlzK6Yovqg&s"
        },
        {
            id: 11,
            title: "Algoritmlar va ma'lumotlar tuzilishi",
            author: "Thomas Cormen",
            description: "Dasturlashda algoritmlar va ma'lumotlar tuzilishini o'rganish uchun eng yaxshi qo'llanma.",
            category: "technology",
            year: 2022,
            pages: 650,
            rating: 4.9,
            coverColor: "#9b59b6",
            tags: ["algoritmlar", "dasturlash", "ma'lumotlar tuzilishi"],
            imageUrl: "https://d280q91s0zg1ey.cloudfront.net/media/images/b68537466f864b35a8c196d507ada966_page_0.jpg"
        },
        {
            id: 12,
            title: "Navoiy she'riyati",
            author: "Alisher Navoiy",
            description: "Buyuk o'zbek shoiri Alisher Navoiyning tanlangan she'rlar to'plami.",
            category: "fiction",
            year: 2021,
            pages: 320,
            rating: 4.8,
            coverColor: "#e74c3c",
            tags: ["she'riyat", "navoiy", "adabiyot"],
            imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTz-U_2KCOgZ0zS8uCo6rulJIPtZU5t8zPwzQ&s"
        }
    ]
};

// DOM elementlari
const featuredBooksContainer = document.getElementById('featuredBooks');
const newBooksContainer = document.getElementById('newBooks');
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const categoryFilter = document.getElementById('categoryFilter');
const yearFilter = document.getElementById('yearFilter');
const bookModal = document.getElementById('bookModal');
const authModal = document.getElementById('authModal');
const modalBody = document.getElementById('modalBody');
const loginBtn = document.getElementById('loginBtn');
const registerBtn = document.getElementById('registerBtn');
const closeModalButtons = document.querySelectorAll('.close-modal');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const switchToRegister = document.getElementById('switchToRegister');
const switchToLogin = document.getElementById('switchToLogin');
const authTabs = document.querySelectorAll('.auth-tab');

// O'zgaruvchilar
let currentUser = null;

// Rangni quyishtirish uchun funksiya
function darkenColor(color, percent) {
    let r = parseInt(color.substring(1, 3), 16);
    let g = parseInt(color.substring(3, 5), 16);
    let b = parseInt(color.substring(5, 7), 16);

    r = parseInt(r * (100 - percent) / 100);
    g = parseInt(g * (100 - percent) / 100);
    b = parseInt(b * (100 - percent) / 100);

    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}

// Yulduzchalarni yaratish
function generateStars(rating) {
    let stars = '';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star"></i>';
    }

    if (hasHalfStar) {
        stars += '<i class="fas fa-star-half-alt"></i>';
    }

    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star"></i>';
    }

    return stars;
}

// Kitob kartalarini yaratish
function createBookCard(book, isNew = false) {
    const card = document.createElement('div');
    card.className = 'book-card';
    card.dataset.id = book.id;
    card.dataset.category = book.category;
    card.dataset.year = book.year;

    // Rasm mavjudligini tekshirish
    const backgroundImage = book.imageUrl ?
        `background-image: url('${book.imageUrl}')` :
        `background: linear-gradient(135deg, ${book.coverColor} 0%, ${darkenColor(book.coverColor, 20)} 100%)`;

    card.innerHTML = `
        <div class="book-cover" style="${backgroundImage}">
            <div class="book-badge" style="color: ${book.coverColor}">
                ${isNew ? 'YANGI' : 'MASHHUR'}
            </div>
        </div>
        <div class="book-info">
            <h3 class="book-title">${book.title}</h3>
            <p class="book-author">${book.author} (${book.year})</p>
            <p class="book-description">${book.description}</p>
            <div class="book-footer">
                <div class="book-rating">
                    ${generateStars(book.rating)}
                    <span>${book.rating} (${Math.floor(Math.random() * 1000) + 100})</span>
                </div>
                <div class="book-actions">
                    <button class="view-details" data-id="${book.id}">Batafsil</button>
                </div>
            </div>
        </div>
    `;

    return card;
}

// Toifa nomini olish
function getCategoryName(category) {
    const categories = {
        fiction: "Badiiy adabiyot",
        science: "Ilmiy adabiyot",
        history: "Tarix",
        technology: "Texnologiya",
        biography: "Biografiya",
        children: "Bolalar adabiyoti"
    };
    return categories[category] || category;
}

// Kitob ma'lumotlarini modalda ko'rsatish
function showBookDetails(bookId) {
    const allBooks = [...booksData.featured, ...booksData.new];
    const book = allBooks.find(b => b.id === parseInt(bookId));

    if (!book) return;

    // Rasm mavjudligini tekshirish
    const coverStyle = book.imageUrl ?
        `background-image: url('${book.imageUrl}')` :
        `background: linear-gradient(135deg, ${book.coverColor} 0%, ${darkenColor(book.coverColor, 20)} 100%)`;

    // Tasodifiy sharhlar soni
    const reviewCount = Math.floor(Math.random() * 50) + 10;

    modalBody.innerHTML = `
        <div class="book-detail">
            <div class="book-detail-header">
                <div class="book-detail-cover" style="${coverStyle}"></div>
                <div class="book-detail-info">
                    <h2 class="book-detail-title">${book.title}</h2>
                    <p class="book-detail-author">${book.author}</p>
                    <div class="book-detail-meta">
                        <span><i class="fas fa-calendar"></i> ${book.year} yil</span>
                        <span><i class="fas fa-book-open"></i> ${book.pages} sahifa</span>
                        <span><i class="fas fa-star"></i> ${book.rating} reyting</span>
                        <span><i class="fas fa-tag"></i> ${getCategoryName(book.category)}</span>
                    </div>
                    <p class="book-detail-description">${book.description}</p>
                    <div class="book-tags">
                        ${book.tags.map(tag => `<span class="tag">#${tag}</span>`).join('')}
                    </div>
                    <div class="book-actions-detail">
                        <button class="btn-read" data-id="${book.id}"><i class="fas fa-book-reader"></i> O'qish</button>
                        <button class="btn-download" data-id="${book.id}"><i class="fas fa-download"></i> Yuklab olish</button>
                        <button class="btn-favorite" data-id="${book.id}"><i class="far fa-heart"></i> Saqlash</button>
                    </div>
                </div>
            </div>
            <div class="book-reviews">
                <h3>Sharhlar (${reviewCount})</h3>
                <div class="review">
                    <div class="review-header">
                        <strong>Ali Valiyev</strong>
                        <div class="review-rating">${generateStars(4.5)}</div>
                    </div>
                    <p class="review-text">Ajoyib kitob! O'qishga boshlaganimdan so'ng to'xtata olmadim. Muallifning uslubi juda jozibali.</p>
                    <div class="review-date">2 kun oldin</div>
                </div>
                <div class="review">
                    <div class="review-header">
                        <strong>Dilnoza Qodirova</strong>
                        <div class="review-rating">${generateStars(4.0)}</div>
                    </div>
                    <p class="review-text">Kitob mazmuni juda boy, lekin ba'zi qismlari murakkab. Yangi boshlovchilar uchun tavsiya etmayman.</p>
                    <div class="review-date">5 kun oldin</div>
                </div>
                <div class="add-review">
                    <h4>Sharh qoldiring</h4>
                    <div class="review-form">
                        <textarea id="reviewText" placeholder="Kitob haqida fikringizni yozing..." rows="3"></textarea>
                        <div class="review-rating-input">
                            <span>Baholang: </span>
                            <div class="stars-input">
                                <i class="far fa-star" data-rating="1"></i>
                                <i class="far fa-star" data-rating="2"></i>
                                <i class="far fa-star" data-rating="3"></i>
                                <i class="far fa-star" data-rating="4"></i>
                                <i class="far fa-star" data-rating="5"></i>
                            </div>
                        </div>
                        <button class="btn-submit-review">Sharh qoldirish</button>
                    </div>
                </div>
            </div>
        </div>
    `;

    bookModal.style.display = 'flex';

    // Teglar uchun CSS qo'shamiz
    const style = document.createElement('style');
    style.innerHTML = `
        .tag {
            display: inline-block;
            background: #f1f8ff;
            color: #3498db;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            margin-right: 8px;
            margin-bottom: 8px;
            transition: all 0.3s;
        }
        .tag:hover {
            background: #3498db;
            color: white;
            transform: translateY(-2px);
        }
        .book-tags {
            margin-bottom: 1.5rem;
            display: flex;
            flex-wrap: wrap;
        }
        .review {
            background: #f8f9fa;
            padding: 1.2rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border-left: 4px solid #3498db;
        }
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        .review-text {
            color: #555;
            line-height: 1.6;
            margin-bottom: 0.5rem;
        }
        .review-date {
            font-size: 0.85rem;
            color: #7f8c8d;
            text-align: right;
        }
        .add-review {
            margin-top: 2rem;
            padding-top: 1.5rem;
            border-top: 1px solid #eee;
        }
        .review-form textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 1rem;
            font-family: 'Roboto', sans-serif;
            resize: vertical;
        }
        .review-rating-input {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 1rem;
        }
        .stars-input i {
            color: #f39c12;
            cursor: pointer;
            font-size: 1.2rem;
            margin-right: 5px;
            transition: color 0.3s;
        }
        .stars-input i:hover {
            color: #f1c40f;
        }
        .btn-submit-review {
            padding: 0.7rem 1.5rem;
            background-color: #2ecc71;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn-submit-review:hover {
            background-color: #27ae60;
        }
        .btn-favorite {
            padding: 0.8rem 1.5rem;
            background-color: #f8f9fa;
            color: #e74c3c;
            border: 1px solid #e74c3c;
            border-radius: 5px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .btn-favorite:hover {
            background-color: #e74c3c;
            color: white;
        }
        .btn-favorite.favorited {
            background-color: #e74c3c;
            color: white;
        }
        .btn-favorite.favorited i {
            color: white;
        }
    `;
    modalBody.appendChild(style);

    // Modal ichidagi hodisalarni sozlash
    setupModalEvents();
}

// Modal ichidagi hodisalarni sozlash
function setupModalEvents() {
    // Baholash yulduzchalari
    const stars = modalBody.querySelectorAll('.stars-input i');
    let selectedRating = 0;

    stars.forEach(star => {
        star.addEventListener('click', function() {
            selectedRating = parseInt(this.dataset.rating);

            // Barcha yulduzchalarni tozalash
            stars.forEach(s => s.className = 'far fa-star');

            // Tanlangan yulduzchalarni to'ldirish
            for (let i = 0; i < selectedRating; i++) {
                stars[i].className = 'fas fa-star';
            }
        });

        // Sichqoncha yulduzcha ustida bo'lganda
        star.addEventListener('mouseover', function() {
            const rating = parseInt(this.dataset.rating);

            stars.forEach((s, index) => {
                if (index < rating) {
                    s.className = 'fas fa-star';
                } else {
                    s.className = 'far fa-star';
                }
            });
        });

        // Sichqoncha yulduzchadan chiqqanda
        star.addEventListener('mouseout', function() {
            stars.forEach((s, index) => {
                if (index < selectedRating) {
                    s.className = 'fas fa-star';
                } else {
                    s.className = 'far fa-star';
                }
            });
        });
    });

    // Sharh qoldirish tugmasi
    const submitReviewBtn = modalBody.querySelector('.btn-submit-review');
    submitReviewBtn.addEventListener('click', function() {
        const reviewText = modalBody.querySelector('#reviewText').value;

        if (!reviewText.trim()) {
            alert('Iltimos, sharh matnini kiriting');
            return;
        }

        if (selectedRating === 0) {
            alert('Iltimos, kitobni baholang');
            return;
        }

        // Bu yerda haqiqiy backendga yuboriladi
        alert('Sharhingiz muvaffaqiyatli qoldirildi! (demo versiya)');
        modalBody.querySelector('#reviewText').value = '';
        selectedRating = 0;
        stars.forEach(s => s.className = 'far fa-star');
    });

    // Kitob harakatlari
    const readBtn = modalBody.querySelector('.btn-read');
    const downloadBtn = modalBody.querySelector('.btn-download');
    const favoriteBtn = modalBody.querySelector('.btn-favorite');

    readBtn.addEventListener('click', function() {
        const bookId = this.dataset.id;
        alert(`"${getBookTitle(bookId)}" kitobini o'qish rejimiga o'tkazildi! (demo)`);
    });

    downloadBtn.addEventListener('click', function() {
        const bookId = this.dataset.id;
        alert(`"${getBookTitle(bookId)}" kitobi yuklab olindi! (demo)`);
    });

    favoriteBtn.addEventListener('click', function() {
        const bookId = this.dataset.id;
        const isFavorited = this.classList.contains('favorited');

        if (isFavorited) {
            this.classList.remove('favorited');
            this.innerHTML = '<i class="far fa-heart"></i> Saqlash';
            alert(`"${getBookTitle(bookId)}" kitobi saqlanganlardan olib tashlandi!`);
        } else {
            this.classList.add('favorited');
            this.innerHTML = '<i class="fas fa-heart"></i> Saqlangan';
            alert(`"${getBookTitle(bookId)}" kitobi saqlanganlarga qo'shildi!`);
        }
    });
}

// Kitob sarlavhasini olish
function getBookTitle(bookId) {
    const allBooks = [...booksData.featured, ...booksData.new];
    const book = allBooks.find(b => b.id === parseInt(bookId));
    return book ? book.title : "Kitob";
}

// Kitoblarni ekranga chiqarish
function displayBooks() {
    featuredBooksContainer.innerHTML = '';
    booksData.featured.forEach(book => {
        const card = createBookCard(book, false);
        featuredBooksContainer.appendChild(card);
    });

    newBooksContainer.innerHTML = '';
    booksData.new.forEach(book => {
        const card = createBookCard(book, true);
        newBooksContainer.appendChild(card);
    });

    setupBookCardEvents();
}

// Kitob kartalariga hodisalarni sozlash
function setupBookCardEvents() {
    document.querySelectorAll('.book-card').forEach(card => {
        card.addEventListener('click', function(e) {
            if (!e.target.classList.contains('view-details')) {
                const bookId = this.dataset.id;
                showBookDetails(bookId);
            }
        });
    });

    document.querySelectorAll('.view-details').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const bookId = this.dataset.id;
            showBookDetails(bookId);
        });
    });
}

// Qidiruv funksiyasi
function performSearch() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    const category = categoryFilter.value;
    const year = yearFilter.value;

    const allBooks = [...booksData.featured, ...booksData.new];

    let filteredBooks = allBooks;

    if (searchTerm) {
        filteredBooks = filteredBooks.filter(book =>
            book.title.toLowerCase().includes(searchTerm) ||
            book.author.toLowerCase().includes(searchTerm) ||
            book.description.toLowerCase().includes(searchTerm) ||
            book.tags.some(tag => tag.toLowerCase().includes(searchTerm)) ||
            book.category.toLowerCase().includes(searchTerm)
        );
    }

    if (category !== 'all') {
        filteredBooks = filteredBooks.filter(book => book.category === category);
    }

    if (year !== 'all') {
        const yearNum = parseInt(year);
        filteredBooks = filteredBooks.filter(book => {
            if (year === '2023') return book.year >= 2023;
            if (year === '2020') return book.year >= 2020 && book.year <= 2022;
            if (year === '2010') return book.year >= 2010 && book.year <= 2019;
            if (year === '2000') return book.year >= 2000 && book.year <= 2009;
            return true;
        });
    }

    // Natijalarni ko'rsatish
    if (filteredBooks.length === 0) {
        featuredBooksContainer.innerHTML = `
            <div class="no-results" style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; background: #f8f9fa; border-radius: 10px;">
                <i class="fas fa-search" style="font-size: 4rem; color: #bdc3c7; margin-bottom: 1.5rem;"></i>
                <h3 style="color: #2c3e50; margin-bottom: 1rem;">Hech qanday natija topilmadi</h3>
                <p style="color: #7f8c8d; max-width: 500px; margin: 0 auto;">"${searchTerm}" bo'yicha hech qanday kitob topilmadi. Qidiruv so'zingizni o'zgartirib ko'ring yoki filtrlarni tozalang.</p>
                <button id="clearFilters" style="margin-top: 1.5rem; padding: 0.8rem 1.5rem; background: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer;">
                    Filtlarni tozalash
                </button>
            </div>
        `;
        newBooksContainer.innerHTML = '';

        // Filtrlarni tozalash tugmasi
        document.getElementById('clearFilters')?.addEventListener('click', function() {
            searchInput.value = '';
            categoryFilter.value = 'all';
            yearFilter.value = 'all';
            displayBooks();
        });
    } else {
        // Mashhur va yangi kitoblarni alohida ko'rsatamiz
        const featuredResults = filteredBooks.filter(book =>
            booksData.featured.some(fb => fb.id === book.id)
        );
        const newResults = filteredBooks.filter(book =>
            booksData.new.some(nb => nb.id === book.id)
        );

        // Mashhur kitoblarni ko'rsatish
        featuredBooksContainer.innerHTML = '';
        if (featuredResults.length > 0) {
            featuredResults.forEach(book => {
                const card = createBookCard(book, false);
                featuredBooksContainer.appendChild(card);
            });
        } else {
            featuredBooksContainer.innerHTML = '<p class="no-results-msg">Mashhur kitoblar orasida natija topilmadi</p>';
        }

        // Yangi kitoblarni ko'rsatish
        newBooksContainer.innerHTML = '';
        if (newResults.length > 0) {
            newResults.forEach(book => {
                const card = createBookCard(book, true);
                newBooksContainer.appendChild(card);
            });
        } else {
            newBooksContainer.innerHTML = '<p class="no-results-msg">Yangi kitoblar orasida natija topilmadi</p>';
        }

        setupBookCardEvents();
    }
}

// Auth modalini boshqarish
function setupAuthModal() {
    loginBtn.addEventListener('click', () => {
        authModal.style.display = 'flex';
        loginForm.classList.remove('hidden');
        registerForm.classList.add('hidden');
        authTabs.forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === 'login');
        });
    });

    registerBtn.addEventListener('click', () => {
        authModal.style.display = 'flex';
        registerForm.classList.remove('hidden');
        loginForm.classList.add('hidden');
        authTabs.forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === 'register');
        });
    });

    authTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.dataset.tab;
            authTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');

            if (tabName === 'login') {
                loginForm.classList.remove('hidden');
                registerForm.classList.add('hidden');
            } else {
                registerForm.classList.remove('hidden');
                loginForm.classList.add('hidden');
            }
        });
    });

    switchToRegister.addEventListener('click', (e) => {
        e.preventDefault();
        loginForm.classList.add('hidden');
        registerForm.classList.remove('hidden');
        authTabs.forEach(tab => tab.classList.toggle('active', tab.dataset.tab === 'register'));
    });

    switchToLogin.addEventListener('click', (e) => {
        e.preventDefault();
        registerForm.classList.add('hidden');
        loginForm.classList.remove('hidden');
        authTabs.forEach(tab => tab.classList.toggle('active', tab.dataset.tab === 'login'));
    });

    // Login formasi
    document.getElementById('submitLogin').addEventListener('click', function() {
        const email = document.getElementById('loginEmail').value.trim();
        const password = document.getElementById('loginPassword').value.trim();

        if (!email || !password) {
            alert('Iltimos, barcha maydonlarni to\'ldiring');
            return;
        }

        // Demo kirish
        if (email === "admin@smartlib.uz" && password === "admin123") {
            currentUser = { name: "Admin", email: email };
            alert('Kirish muvaffaqiyatli! Admin paneliga xush kelibsiz!');
        } else {
            currentUser = { name: email.split('@')[0], email: email };
            alert('Kirish muvaffaqiyatli! Smart Libraryga xush kelibsiz!');
        }

        authModal.style.display = 'none';
        loginBtn.innerHTML = `<i class="fas fa-user"></i> ${currentUser.name}`;
        loginBtn.classList.add('logged-in');
        registerBtn.style.display = 'none';
    });

    // Ro'yxatdan o'tish formasi
    document.getElementById('submitRegister').addEventListener('click', function() {
        const name = document.getElementById('registerName').value.trim();
        const email = document.getElementById('registerEmail').value.trim();
        const password = document.getElementById('registerPassword').value.trim();
        const confirmPassword = document.getElementById('registerConfirmPassword').value.trim();

        if (!name || !email || !password || !confirmPassword) {
            alert('Iltimos, barcha maydonlarni to\'ldiring');
            return;
        }

        if (password !== confirmPassword) {
            alert('Parollar mos kelmadi');
            return;
        }

        if (password.length < 8) {
            alert('Parol kamida 8 ta belgidan iborat bo\'lishi kerak');
            return;
        }

        if (!email.includes('@')) {
            alert('Iltimos, to\'g\'ri elektron pochta manzilini kiriting');
            return;
        }

        currentUser = { name: name, email: email };
        alert(`Hurmatli ${name}, ro'yxatdan o'tish muvaffaqiyatli! Smart Libraryga xush kelibsiz!`);
        authModal.style.display = 'none';
        loginBtn.innerHTML = `<i class="fas fa-user"></i> ${name}`;
        loginBtn.classList.add('logged-in');
        registerBtn.style.display = 'none';

        // Yangi foydalanuvchini "saqlanganlar" ro'yxatini yaratish
        localStorage.setItem('favorites', JSON.stringify([]));
    });
}

// Sahifa yuklanganda ishlaydigan funksiyalar
document.addEventListener('DOMContentLoaded', function() {
    displayBooks();
    setupAuthModal();

    // Qidiruvni sozlash
    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });

    // Filtrlarni sozlash
    categoryFilter.addEventListener('change', performSearch);
    yearFilter.addEventListener('change', performSearch);

    // Modalni yopish
    closeModalButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            bookModal.style.display = 'none';
            authModal.style.display = 'none';
        });
    });

    // Tashqariga klik qilganda modalni yopish
    window.addEventListener('click', function(e) {
        if (e.target === bookModal) {
            bookModal.style.display = 'none';
        }
        if (e.target === authModal) {
            authModal.style.display = 'none';
        }
    });

    // Toifa kartalarini sozlash
    document.querySelectorAll('.category-card').forEach(card => {
        card.addEventListener('click', function() {
            const category = this.dataset.category;
            categoryFilter.value = category;
            performSearch();
            document.querySelector('.categories-section').scrollIntoView({behavior: 'smooth'});
        });
    });

    // Mobil menyu
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    const userActions = document.querySelector('.user-actions');

    mobileMenuBtn.addEventListener('click', function() {
        const isMobile = window.innerWidth <= 768;

        if (isMobile) {
            if (navLinks.style.display === 'flex') {
                navLinks.style.display = 'none';
                userActions.style.display = 'none';
                mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            } else {
                navLinks.style.display = 'flex';
                userActions.style.display = 'flex';
                mobileMenuBtn.innerHTML = '<i class="fas fa-times"></i>';

                navLinks.style.flexDirection = 'column';
                navLinks.style.position = 'absolute';
                navLinks.style.top = '100%';
                navLinks.style.left = '0';
                navLinks.style.right = '0';
                navLinks.style.backgroundColor = 'white';
                navLinks.style.padding = '1.5rem';
                navLinks.style.boxShadow = '0 5px 15px rgba(0,0,0,0.1)';
                navLinks.style.gap = '1.2rem';

                userActions.style.flexDirection = 'column';
                userActions.style.position = 'absolute';
                userActions.style.top = `calc(100% + ${navLinks.offsetHeight}px)`;
                userActions.style.left = '0';
                userActions.style.right = '0';
                userActions.style.backgroundColor = 'white';
                userActions.style.padding = '1.5rem';
                userActions.style.boxShadow = '0 5px 15px rgba(0,0,0,0.1)';
                userActions.style.gap = '1rem';
            }
        }
    });

    // Oyna o'lchami o'zgarganda mobil menyuni to'g'rilash
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            navLinks.style.display = 'flex';
            userActions.style.display = 'flex';
            navLinks.style.flexDirection = 'row';
            navLinks.style.position = 'static';
            navLinks.style.backgroundColor = 'transparent';
            navLinks.style.padding = '0';
            navLinks.style.boxShadow = 'none';

            userActions.style.flexDirection = 'row';
            userActions.style.position = 'static';
            userActions.style.backgroundColor = 'transparent';
            userActions.style.padding = '0';
            userActions.style.boxShadow = 'none';

            mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
        } else {
            navLinks.style.display = 'none';
            userActions.style.display = 'none';
        }
    });

    // Yuklangan kitoblarni saqlash
    console.log('Smart Library sayti muvaffaqiyatli yuklandi!');
    console.log(`Jami ${booksData.featured.length + booksData.new.length} ta kitob mavjud`);

    // Yangi yil filterini yangilash
    const currentYear = new Date().getFullYear();
    const yearFilterSelect = document.getElementById('yearFilter');
    yearFilterSelect.innerHTML = `
        <option value="all">Barcha yillar</option>
        <option value="${currentYear}">${currentYear} va undan keyin</option>
        <option value="${currentYear - 3}">${currentYear - 3}-${currentYear - 1}</option>
        <option value="${currentYear - 10}">${currentYear - 10}-${currentYear - 4}</option>
        <option value="2000">2000-${currentYear - 11}</option>
    `;
});