 // Testlar ma'lumotlar bazasi
        const testlar = {
            matematika: {
                nomi: 'Matematika',
                savollar: [
                    {
                        savol: "7 × 8 = ?",
                        variantlar: ["48", "56", "64", "72"],
                        togri: 1
                    },
                    {
                        savol: "144 ning kvadrat ildizi nechiga teng?",
                        variantlar: ["10", "11", "12", "13"],
                        togri: 2
                    },
                    {
                        savol: "3x + 5 = 20 tenglamani yeching",
                        variantlar: ["3", "5", "7", "9"],
                        togri: 1
                    },
                    {
                        savol: "15 ning 20% i nechiga teng?",
                        variantlar: ["2", "3", "4", "5"],
                        togri: 1
                    },
                    {
                        savol: "To'g'ri to'rtburchakning yuzi 48 cm², eni 6 cm bo'lsa, bo'yi necha cm?",
                        variantlar: ["6", "7", "8", "9"],
                        togri: 2
                    },
                    {
                        savol: "0.75 kasrni oddiy kasr ko'rinishida yozing",
                        variantlar: ["3/4", "1/2", "2/3", "5/6"],
                        togri: 0
                    },
                    {
                        savol: "5! (faktorial) nechiga teng?",
                        variantlar: ["60", "120", "240", "360"],
                        togri: 1
                    },
                    {
                        savol: "Agar a = 3, b = 4 bo'lsa, a² + b² = ?",
                        variantlar: ["7", "12", "25", "49"],
                        togri: 2
                    },
                    {
                        savol: "360 sonining nechta natural bo'luvchisi bor?",
                        variantlar: ["18", "20", "24", "36"],
                        togri: 2
                    },
                    {
                        savol: "log₂ 16 = ?",
                        variantlar: ["2", "4", "8", "16"],
                        togri: 1
                    },
                    {
                        savol: "Uchburchak ichki burchaklari yig'indisi necha gradus?",
                        variantlar: ["90°", "180°", "270°", "360°"],
                        togri: 1
                    },
                    {
                        savol: "Aylananing uzunligi formulasi qaysi?",
                        variantlar: ["2πr", "πr²", "πd", "2πd"],
                        togri: 0
                    },
                    {
                        savol: "125 ning kub ildizi nechiga teng?",
                        variantlar: ["3", "4", "5", "6"],
                        togri: 2
                    },
                    {
                        savol: "45 soni 60 ning necha foizini tashkil qiladi?",
                        variantlar: ["65%", "70%", "75%", "80%"],
                        togri: 2
                    },
                    {
                        savol: "Eng kichik tub son qaysi?",
                        variantlar: ["0", "1", "2", "3"],
                        togri: 2
                    },
                    {
                        savol: "18 va 24 ning EKUB i nechaga teng?",
                        variantlar: ["4", "6", "8", "12"],
                        togri: 1
                    },
                    {
                        savol: "0.1 + 0.2 = ?",
                        variantlar: ["0.2", "0.3", "0.4", "0.5"],
                        togri: 1
                    },
                    {
                        savol: "x² = 49 tenglamaning ildizlari",
                        variantlar: ["±5", "±6", "±7", "±8"],
                        togri: 2
                    },
                    {
                        savol: "Kvadratning perimetri 32 cm bo'lsa, uning yuzi necha cm²?",
                        variantlar: ["64", "128", "256", "512"],
                        togri: 0
                    },
                    {
                        savol: "1 soatda necha sekund bor?",
                        variantlar: ["1800", "2400", "3600", "4800"],
                        togri: 2
                    },
                    {
                        savol: "3² + 4² = ?",
                        variantlar: ["5²", "6²", "7²", "8²"],
                        togri: 0
                    },
                    {
                        savol: "15 va 25 ning EKUK i nechaga teng?",
                        variantlar: ["45", "55", "65", "75"],
                        togri: 3
                    },
                    {
                        savol: "2/3 + 1/4 = ?",
                        variantlar: ["3/7", "8/12", "11/12", "5/7"],
                        togri: 2
                    },
                    {
                        savol: "0.125 kasrni foizda ifodalang",
                        variantlar: ["1.25%", "12.5%", "125%", "1250%"],
                        togri: 1
                    },
                    {
                        savol: "√144 + √169 = ?",
                        variantlar: ["12", "13", "25", "313"],
                        togri: 2
                    }
                ]
            },
            fizika: {
                nomi: 'Fizika',
                savollar: [
                    {
                        savol: "Tezlik formulasi qaysi?",
                        variantlar: ["v = s/t", "v = s × t", "v = t/s", "v = s + t"],
                        togri: 0
                    },
                    {
                        savol: "Yorug'lik tezligi taxminan necha km/s?",
                        variantlar: ["150,000", "200,000", "300,000", "400,000"],
                        togri: 2
                    },
                    {
                        savol: "Nyutonning birinchi qonuni qaysi?",
                        variantlar: ["Inersiya qonuni", "Kuch va tezlanish", "Aks ta'sir qonuni", "Tortishish qonuni"],
                        togri: 0
                    },
                    {
                        savol: "Elektr tokining birligi nima?",
                        variantlar: ["Volt", "Amper", "Om", "Vatt"],
                        togri: 1
                    },
                    {
                        savol: "Ovoz qaysi muhitda tez tarqaladi?",
                        variantlar: ["Gazda", "Suyuqlikda", "Qattiq jismda", "Vakuumda"],
                        togri: 2
                    },
                    {
                        savol: "Erkin tushish tezlanishi taxminan necha m/s²?",
                        variantlar: ["5.8", "7.8", "9.8", "11.8"],
                        togri: 2
                    },
                    {
                        savol: "Atom yadrosida nimalar bor?",
                        variantlar: ["Elektron va proton", "Proton va neytron", "Neytron va elektron", "Faqat proton"],
                        togri: 1
                    },
                    {
                        savol: "Ish formulasi qaysi?",
                        variantlar: ["A = F × s", "A = F/s", "A = F + s", "A = F - s"],
                        togri: 0
                    },
                    {
                        savol: "Bosim birligi nima?",
                        variantlar: ["Nyuton", "Joul", "Paskal", "Vatt"],
                        togri: 2
                    },
                    {
                        savol: "Suvning zichligi necha kg/m³?",
                        variantlar: ["500", "800", "1000", "1200"],
                        togri: 2
                    },
                    {
                        savol: "Radioaktivlikni kim kashf etgan?",
                        variantlar: ["Kyuri", "Rezerford", "Bekkerel", "Eynshteyn"],
                        togri: 2
                    },
                    {
                        savol: "Optik kuch birligi nima?",
                        variantlar: ["Dioptriya", "Lyuks", "Lyumen", "Kandela"],
                        togri: 0
                    },
                    {
                        savol: "Kondensator nima o'lchaydi?",
                        variantlar: ["Qarshilik", "Sig'im", "Induktivlik", "Quvvat"],
                        togri: 1
                    },
                    {
                        savol: "Fokus masofasi 20 sm bo'lgan linzaning optik kuchi?",
                        variantlar: ["2 D", "5 D", "10 D", "20 D"],
                        togri: 1
                    },
                    {
                        savol: "Magnit maydonining manbai nima?",
                        variantlar: ["Elektr zaryadi", "Harakatlanuvchi zaryad", "Magnit", "Temir"],
                        togri: 1
                    },
                    {
                        savol: "Yadro reaksiyasida qanday qonun saqlanadi?",
                        variantlar: ["Massa", "Energiya", "Zaryad", "Hammasi"],
                        togri: 3
                    },
                    {
                        savol: "Fotonning massasi qancha?",
                        variantlar: ["0", "1", "2", "3"],
                        togri: 0
                    },
                    {
                        savol: "Qattiq jismlarda issiqlik qanday tarqaladi?",
                        variantlar: ["Konveksiya", "Nurlanish", "Issiqlik o'tkazuvchanlik", "Aralsh"],
                        togri: 2
                    },
                    {
                        savol: "Gazlarda molekulalar orasidagi masofa?",
                        variantlar: ["Kichik", "Katta", "O'rtacha", "Juda kichik"],
                        togri: 1
                    },
                    {
                        savol: "Molekulyar fizikada temperatura nima?",
                        variantlar: ["Energiya", "Kinetik energiya o'lchovi", "Tezlik", "Bosim"],
                        togri: 1
                    },
                    {
                        savol: "Elektr maydon kuchlanganligi birligi?",
                        variantlar: ["V/m", "A/m", "T", "Wb"],
                        togri: 0
                    },
                    {
                        savol: "Transformator nimaga asoslangan?",
                        variantlar: ["Elektroliz", "Elektromagnit induksiya", "Termoelektrik", "Fotoeffekt"],
                        togri: 1
                    },
                    {
                        savol: "Laver ko'zgu formulasi?",
                        variantlar: ["1/F = 1/d + 1/f", "F = d × f", "d = F × f", "f = F × d"],
                        togri: 0
                    },
                    {
                        savol: "Rezonans hodisasi qayerda kuzatiladi?",
                        variantlar: ["Mexanika", "Elektr", "Akustika", "Hammasida"],
                        togri: 3
                    },
                    {
                        savol: "Zaryad birligi nima?",
                        variantlar: ["Amper", "Volt", "Kulon", "Farad"],
                        togri: 2
                    }
                ]
            },
            kimyo: {
                nomi: 'Kimyo',
                savollar: [
                    {
                        savol: "Suvning kimyoviy formulasi?",
                        variantlar: ["H2O", "CO2", "O2", "H2O2"],
                        togri: 0
                    },
                    {
                        savol: "Kislotalarning ta'mi qanday?",
                        variantlar: ["Shirin", "Achchiq", "Nordon", "Sho'r"],
                        togri: 2
                    },
                    {
                        savol: "Mendeleyev jadvalida nechta element bor?",
                        variantlar: ["108", "110", "118", "120"],
                        togri: 2
                    },
                    {
                        savol: "Havoning asosiy tarkibiy qismi?",
                        variantlar: ["Kislorod", "Azot", "Vodorod", "Karbonat angidrid"],
                        togri: 1
                    },
                    {
                        savol: "Oltinning kimyoviy belgisi?",
                        variantlar: ["Ag", "Au", "Al", "Ar"],
                        togri: 1
                    },
                    {
                        savol: "pH qiymati 7 dan kichik bo'lgan eritma?",
                        variantlar: ["Ishqoriy", "Neytral", "Kislotali", "Tuzli"],
                        togri: 2
                    },
                    {
                        savol: "Eng yengil gaz?",
                        variantlar: ["Kislorod", "Azot", "Vodorod", "Geliy"],
                        togri: 2
                    },
                    {
                        savol: "Tuzning kimyoviy nomi?",
                        variantlar: ["Natriy xlorid", "Kaliy xlorid", "Kalsiy xlorid", "Magniy xlorid"],
                        togri: 0
                    },
                    {
                        savol: "Kislotali yomg'irlarga sabab?",
                        variantlar: ["CO2", "SO2", "NO2", "Hammasi"],
                        togri: 3
                    },
                    {
                        savol: "Organik birikmalarning asosiy elementi?",
                        variantlar: ["Kislorod", "Vodorod", "Uglerod", "Azot"],
                        togri: 2
                    },
                    {
                        savol: "Metanning formulasi?",
                        variantlar: ["CH4", "C2H6", "C3H8", "C4H10"],
                        togri: 0
                    },
                    {
                        savol: "Spirtlarning funksional guruhi?",
                        variantlar: ["-OH", "-COOH", "-CHO", "-NH2"],
                        togri: 0
                    },
                    {
                        savol: "Eng qattiq modda?",
                        variantlar: ["Temir", "Olmos", "Kvars", "Granit"],
                        togri: 1
                    },
                    {
                        savol: "Katalizator nima qiladi?",
                        variantlar: ["Tezlashtiradi", "Sekinlashtiradi", "O'zgartiradi", "To'xtatadi"],
                        togri: 0
                    },
                    {
                        savol: "Neytrallanish reaksiyasi?",
                        variantlar: ["Kislota + asos", "Metall + kislota", "Oksid + suv", "Tuz + suv"],
                        togri: 0
                    },
                    {
                        savol: "Izotoplar farqlanadi?",
                        variantlar: ["Proton soni", "Neytron soni", "Elektron soni", "Zaryadi"],
                        togri: 1
                    },
                    {
                        savol: "Valentlik nima?",
                        variantlar: ["Atom massasi", "Bog'lanish soni", "Zaryad", "Elektron soni"],
                        togri: 1
                    },
                    {
                        savol: "Oksidlanish darajasi o'zgarishi?",
                        variantlar: ["Oksidlanish", "Qaytarilish", "Neytrallanish", "Parchalanish"],
                        togri: 0
                    },
                    {
                        savol: "Asoslarning xossasi?",
                        variantlar: ["Kislota bilan reaksiya", "Metall bilan reaksiya", "Tuz hosil qilish", "Hammasi"],
                        togri: 3
                    },
                    {
                        savol: "Polimerlarga misol?",
                        variantlar: ["Polietilen", "PVX", "Kauchuk", "Hammasi"],
                        togri: 3
                    },
                    {
                        savol: "Fermentlar nima?",
                        variantlar: ["Biologik katalizator", "Vitamin", "Gormon", "Oqsil"],
                        togri: 0
                    },
                    {
                        savol: "Distillash usuli?",
                        variantlar: ["Suyuqliklarni ajratish", "Qattiq moddalarni ajratish", "Gazlarni ajratish", "Eritmalarni ajratish"],
                        togri: 0
                    },
                    {
                        savol: "Kristallanish nima?",
                        variantlar: ["Qattiq holatga o'tish", "Suyuq holatga o'tish", "Gaz holatga o'tish", "Bug'lanish"],
                        togri: 0
                    },
                    {
                        savol: "Alyuminiyning valentligi?",
                        variantlar: ["1", "2", "3", "4"],
                        togri: 2
                    },
                    {
                        savol: "Kislotaning xossasi?",
                        variantlar: ["Metall bilan reaksiya", "Indikator rangini o'zgartirish", "Asos bilan reaksiya", "Hammasi"],
                        togri: 3
                    }
                ]
            },
            biologiya: {
                nomi: 'Biologiya',
                savollar: [
                    {
                        savol: "Inson yurak qorinchalari soni?",
                        variantlar: ["1", "2", "3", "4"],
                        togri: 1
                    },
                    {
                        savol: "Fotosintez qayerda sodir bo'ladi?",
                        variantlar: ["Mitoxondriya", "Xloroplast", "Yadro", "Ribosoma"],
                        togri: 1
                    },
                    {
                        savol: "DNK ning to'liq nomi?",
                        variantlar: ["Dezoksiribonuklein kislota", "Ribonuklein kislota", "Adenozin trifosfat", "Protein"],
                        togri: 0
                    },
                    {
                        savol: "Inson miyasining og'irligi taxminan?",
                        variantlar: ["0.5 kg", "1 kg", "1.5 kg", "2 kg"],
                        togri: 2
                    },
                    {
                        savol: "Eng katta organ?",
                        variantlar: ["Yurak", "Jigar", "O'pka", "Ter"],
                        togri: 3
                    },
                    {
                        savol: "Qon guruhlarini kim kashf etgan?",
                        variantlar: ["Landsteiner", "Pavlov", "Darvin", "Mendel"],
                        togri: 0
                    },
                    {
                        savol: "Akson nima?",
                        variantlar: ["Neyron tanasi", "Neyron o'simtasi", "Sinaps", "Dendrit"],
                        togri: 1
                    },
                    {
                        savol: "Qaysi vitamin C ga boy?",
                        variantlar: ["Limon", "Sabzi", "Sut", "Non"],
                        togri: 0
                    },
                    {
                        savol: "Antibiotiklarni kim kashf etgan?",
                        variantlar: ["Fleming", "Paster", "Kox", "Mechnikov"],
                        togri: 0
                    },
                    {
                        savol: "Gormonlarni ishlab chiqaradigan organ?",
                        variantlar: ["Jigar", "Oshqozon osti bezi", "Buyrak", "O'pka"],
                        togri: 1
                    },
                    {
                        savol: "Mendel qonunlari?",
                        variantlar: ["Irsiyat", "O'zgaruvchanlik", "Seleksiya", "Evolutsiya"],
                        togri: 0
                    },
                    {
                        savol: "Gemoglobin vazifasi?",
                        variantlar: ["Kislorod tashish", "CO2 tashish", "Oziq tashish", "Himoya"],
                        togri: 0
                    },
                    {
                        savol: "O'simliklarning suv bug'lanishi?",
                        variantlar: ["Transpiratsiya", "Fotosintez", "Nafas olish", "Oziqlanish"],
                        togri: 0
                    },
                    {
                        savol: "Xromosomalar soni odamda?",
                        variantlar: ["23", "24", "46", "48"],
                        togri: 2
                    },
                    {
                        savol: "Fagotsitoz nima?",
                        variantlar: ["Yutish", "Bo'lish", "O'sish", "Ko'payish"],
                        togri: 0
                    },
                    {
                        savol: "Organizmning tashqi muhit ta'siriga javobi?",
                        variantlar: ["Refleks", "Instinkt", "Irsiyat", "O'zgaruvchanlik"],
                        togri: 0
                    },
                    {
                        savol: "Oqsil sintezi joyi?",
                        variantlar: ["Ribosoma", "Mitoxondriya", "Golji", "Lizosoma"],
                        togri: 0
                    },
                    {
                        savol: "Xlorofill rangi?",
                        variantlar: ["Qizil", "Sariq", "Yashil", "Ko'k"],
                        togri: 2
                    },
                    {
                        savol: "Sut emizuvchilar sinfi?",
                        variantlar: ["Mammalia", "Aves", "Reptilia", "Amphibia"],
                        togri: 0
                    },
                    {
                        savol: "Gomeostaz nima?",
                        variantlar: ["Doimiylik", "O'zgaruvchanlik", "Moslashuv", "Rivojlanish"],
                        togri: 0
                    },
                    {
                        savol: "Mitoz nima?",
                        variantlar: ["Hujayra bo'linishi", "Organizm bo'linishi", "To'qima bo'linishi", "Organ bo'linishi"],
                        togri: 0
                    },
                    {
                        savol: "Genetik kod nima?",
                        variantlar: ["DNK ketma-ketligi", "RNK ketma-ketligi", "Protein ketma-ketligi", "Aminokislota"],
                        togri: 0
                    },
                    {
                        savol: "Fotosintez maxsuloti?",
                        variantlar: ["Kraxmal", "Oqsil", "Yog'", "Vitamin"],
                        togri: 0
                    },
                    {
                        savol: "Immunitet nima?",
                        variantlar: ["Himoya", "Oziqlanish", "Nafas olish", "Qon aylanish"],
                        togri: 0
                    },
                    {
                        savol: "Ekologiya nima?",
                        variantlar: ["Organizm va muhit", "Organizm tuzilishi", "Organizm funksiyasi", "Organizm rivojlanishi"],
                        togri: 0
                    }
                ]
            },
            tarix: {
                nomi: 'Tarix',
                savollar: [
                    {
                        savol: "Amir Temur qachon tug'ilgan?",
                        variantlar: ["1336", "1337", "1338", "1339"],
                        togri: 0
                    },
                    {
                        savol: "Birinchi jahon urushi qachon boshlangan?",
                        variantlar: ["1912", "1914", "1916", "1918"],
                        togri: 1
                    },
                    {
                        savol: "Buyuk ipak yo'li qayerdan o'tgan?",
                        variantlar: ["Xitoy - Yevropa", "Hindiston - Rim", "Misr - Yunoniston", "Rossiya - Xitoy"],
                        togri: 0
                    },
                    {
                        savol: "Sohibqiron unvoni kimga tegishli?",
                        variantlar: ["Bobur", "Amir Temur", "Jaloliddin Manguberdi", "Alisher Navoiy"],
                        togri: 1
                    },
                    {
                        savol: "Fransuz inqilobi qachon bo'lgan?",
                        variantlar: ["1789", "1776", "1812", "1848"],
                        togri: 0
                    },
                    {
                        savol: "Qadimgi Misr poytaxti?",
                        variantlar: ["Qohira", "Iskandariya", "Fiv", "Memfis"],
                        togri: 3
                    },
                    {
                        savol: "Kolumb Amerikani qachon kashf etgan?",
                        variantlar: ["1492", "1482", "1502", "1512"],
                        togri: 0
                    },
                    {
                        savol: "Buyuk Aleksandr (Makedonskiy) qayerda tug'ilgan?",
                        variantlar: ["Yunoniston", "Makedoniya", "Misr", "Fors"],
                        togri: 1
                    },
                    {
                        savol: "Rim imperiyasining poytaxti?",
                        variantlar: ["Rim", "Vizantiya", "Karfagen", "Athens"],
                        togri: 0
                    },
                    {
                        savol: "Islom taqvimi qachondan boshlanadi?",
                        variantlar: ["570", "622", "632", "661"],
                        togri: 1
                    },
                    {
                        savol: "Buyuk Britaniya qirolichasi Viktoriya hukmronligi?",
                        variantlar: ["1819-1901", "1837-1901", "1850-1901", "1860-1901"],
                        togri: 1
                    },
                    {
                        savol: "Xiva xonligi poytaxti?",
                        variantlar: ["Xiva", "Buxoro", "Samarqand", "Toshkent"],
                        togri: 0
                    },
                    {
                        savol: "Buxoro amirligi qachon tugatilgan?",
                        variantlar: ["1917", "1918", "1920", "1924"],
                        togri: 2
                    },
                    {
                        savol: "Jaloliddin Manguberdi qaysi davlat hukmdori?",
                        variantlar: ["Xorazm", "Saljuqiylar", "Mamluks", "Oltin O'rda"],
                        togri: 0
                    },
                    {
                        savol: "Maroqash rasadxonasini kim qurdirgan?",
                        variantlar: ["Ulug'bek", "Nasiriddin Tusi", "Beruniy", "Ibn Sino"],
                        togri: 1
                    },
                    {
                        savol: "Buyuk ipak yo'li qachon paydo bo'lgan?",
                        variantlar: ["Miloddan avvalgi II asr", "Milodiy I asr", "Milodiy V asr", "Milodiy X asr"],
                        togri: 0
                    },
                    {
                        savol: "Qadimgi Yunonistonning eng mashhur shahri?",
                        variantlar: ["Afina", "Sparta", "Fiv", "Korinf"],
                        togri: 0
                    },
                    {
                        savol: "Vatikan qayerda joylashgan?",
                        variantlar: ["Rim", "Parij", "Madrid", "Lissabon"],
                        togri: 0
                    },
                    {
                        savol: "Buyuk Xitoy devori qachon qurilgan?",
                        variantlar: ["Miloddan avvalgi III asr", "Milodiy I asr", "Milodiy X asr", "Milodiy XV asr"],
                        togri: 0
                    },
                    {
                        savol: "Qora dengiz qayerda joylashgan?",
                        variantlar: ["Yevropa va Osiyo o'rtasida", "Afrika va Yevropa o'rtasida", "Osiyo va Afrika o'rtasida", "Amerika va Yevropa o'rtasida"],
                        togri: 0
                    },
                    {
                        savol: "Birinchi prezidentimiz kim?",
                        variantlar: ["Islom Karimov", "Shavkat Mirziyoyev", "Abdulla Oripov", "Erkin Vohidov"],
                        togri: 0
                    },
                    {
                        savol: "Mustaqillik qachon e'lon qilingan?",
                        variantlar: ["1990", "1991", "1992", "1993"],
                        togri: 1
                    },
                    {
                        savol: "Konstitutsiya qachon qabul qilingan?",
                        variantlar: ["1991", "1992", "1993", "1994"],
                        togri: 1
                    },
                    {
                        savol: "Samarqand qachon tashkil topgan?",
                        variantlar: ["Miloddan avvalgi VIII asr", "Miloddan avvalgi VII asr", "Miloddan avvalgi VI asr", "Miloddan avvalgi V asr"],
                        togri: 0
                    },
                    {
                        savol: "Registon maydoni qayerda?",
                        variantlar: ["Samarqand", "Buxoro", "Xiva", "Toshkent"],
                        togri: 0
                    }
                ]
            },
            geografiya: {
                nomi: 'Geografiya',
                savollar: [
                    {
                        savol: "Eng katta okean?",
                        variantlar: ["Atlantika", "Hind", "Tinch", "Shimoliy Muz"],
                        togri: 2
                    },
                    {
                        savol: "O'zbekiston poytaxti?",
                        variantlar: ["Samarqand", "Buxoro", "Toshkent", "Farg'ona"],
                        togri: 2
                    },
                    {
                        savol: "Eng baland cho'qqi?",
                        variantlar: ["Elbrus", "Everest", "Montblan", "Kilimanjaro"],
                        togri: 1
                    },
                    {
                        savol: "Eng uzun daryo?",
                        variantlar: ["Nil", "Amazonka", "Xuanxe", "Missisipi"],
                        togri: 0
                    },
                    {
                        savol: "Qaysi davlat eng katta maydonga ega?",
                        variantlar: ["AQSH", "Kanada", "Xitoy", "Rossiya"],
                        togri: 3
                    },
                    {
                        savol: "Orol dengizi qayerda joylashgan?",
                        variantlar: ["Qozog'iston va O'zbekiston", "Turkmaniston va O'zbekiston", "Qirg'iziston va O'zbekiston", "Tojikiston va O'zbekiston"],
                        togri: 0
                    },
                    {
                        savol: "Eng kichik davlat?",
                        variantlar: ["Monako", "Vatikan", "San-Marino", "Malta"],
                        togri: 1
                    },
                    {
                        savol: "Qaysi materik eng katta?",
                        variantlar: ["Afrika", "Shimoliy Amerika", "Osiyo", "Janubiy Amerika"],
                        togri: 2
                    },
                    {
                        savol: "Kaspiy dengizi qanday suv havzasi?",
                        variantlar: ["Dengiz", "Ko'l", "Okean", "Daryo"],
                        togri: 1
                    },
                    {
                        savol: "Qaysi davlat ikki qit'ada joylashgan?",
                        variantlar: ["Misr", "Turkiya", "Rossiya", "Hammasi"],
                        togri: 3
                    },
                    {
                        savol: "Eng chuqur okean?",
                        variantlar: ["Atlantika", "Tinch", "Hind", "Shimoliy Muz"],
                        togri: 1
                    },
                    {
                        savol: "Pomir tog' tizmasi qayerda?",
                        variantlar: ["O'zbekiston", "Tojikiston", "Qirg'iziston", "Turkmaniston"],
                        togri: 1
                    },
                    {
                        savol: "Eng katta cho'l?",
                        variantlar: ["Saxara", "Gobi", "Kalahari", "Arabiston"],
                        togri: 0
                    },
                    {
                        savol: "Amudaryo qayerga quyiladi?",
                        variantlar: ["Orol dengizi", "Kaspiy dengizi", "Sirdaryo", "Ko'l"],
                        togri: 0
                    },
                    {
                        savol: "Baykal ko'li qayerda?",
                        variantlar: ["Rossiya", "Mongoliya", "Xitoy", "Qozog'iston"],
                        togri: 0
                    },
                    {
                        savol: "Eng katta orol?",
                        variantlar: ["Grenlandiya", "Yangi Gvineya", "Borneo", "Madagaskar"],
                        togri: 0
                    },
                    {
                        savol: "Ekologik muammolardan biri?",
                        variantlar: ["Orol muammosi", "Havo ifloslanishi", "Suv ifloslanishi", "Hammasi"],
                        togri: 3
                    },
                    {
                        savol: "Qaysi shahar ikkita qit'ada joylashgan?",
                        variantlar: ["Istanbul", "Moskva", "Qohira", "Rim"],
                        togri: 0
                    },
                    {
                        savol: "Eng baland sharshara?",
                        variantlar: ["Anxel", "Viktoriya", "Niagara", "Iguazu"],
                        togri: 0
                    },
                    {
                        savol: "Qaysi dengiz qurib bormoqda?",
                        variantlar: ["Orol", "Kaspiy", "O'lik", "Qizil"],
                        togri: 0
                    },
                    {
                        savol: "Tyan-Shan tog'lari qayerda?",
                        variantlar: ["Markaziy Osiyo", "Janubiy Osiyo", "Sharqiy Osiyo", "G'arbiy Osiyo"],
                        togri: 0
                    },
                    {
                        savol: "Farg'ona vodiysi qaysi davlatlar o'rtasida?",
                        variantlar: ["O'zbekiston, Qirg'iziston, Tojikiston", "O'zbekiston, Qozog'iston, Turkmaniston", "O'zbekiston, Tojikiston, Turkmaniston", "O'zbekiston, Qirg'iziston, Qozog'iston"],
                        togri: 0
                    },
                    {
                        savol: "Eng issiq joy?",
                        variantlar: ["Saxara", "Eron", "Iroq", "Kuvayt"],
                        togri: 3
                    },
                    {
                        savol: "Eng sovuq joy?",
                        variantlar: ["Antarktida", "Sibir", "Kanada", "Grenlandiya"],
                        togri: 0
                    },
                    {
                        savol: "Chorvoq suv ombori qayerda?",
                        variantlar: ["Toshkent viloyati", "Samarqand viloyati", "Buxoro viloyati", "Farg'ona viloyati"],
                        togri: 0
                    }
                ]
            },
            adabiyot: {
                nomi: 'Adabiyot',
                savollar: [
                    {
                        savol: "Alisher Navoiyning eng mashhur asari?",
                        variantlar: ["Xamsa", "Lison ut-Tayr", "Mahbub ul-Qulub", "Hayrat ul-Abror"],
                        togri: 0
                    },
                    {
                        savol: "'O'tgan kunlar' romani muallifi?",
                        variantlar: ["Cho'lpon", "Oybek", "Abdulla Qodiriy", "G'afur G'ulom"],
                        togri: 2
                    },
                    {
                        savol: "Boburning mashhur asari?",
                        variantlar: ["Devon", "Xamsa", "Boburnoma", "Mahbub ul-Qulub"],
                        togri: 2
                    },
                    {
                        savol: "Furqatning asl ismi?",
                        variantlar: ["Zokirjon", "Abdurahmon", "Tohir", "Mahmud"],
                        togri: 0
                    },
                    {
                        savol: "Hamza Hakimzoda Niyoziy qaysi asrda yashagan?",
                        variantlar: ["XVIII", "XIX", "XX", "XXI"],
                        togri: 2
                    },
                    {
                        savol: "Ruboiy janrining ustasi?",
                        variantlar: ["Fuzuliy", "Navoiy", "Bobur", "Umar Xayyom"],
                        togri: 3
                    },
                    {
                        savol: "Zahiriddin Muhammad Bobur qayerda tug'ilgan?",
                        variantlar: ["Andijon", "Farg'ona", "Samarqand", "Toshkent"],
                        togri: 0
                    },
                    {
                        savol: "Maqollar qaysi janrga kiradi?",
                        variantlar: ["Lirika", "Epos", "Drama", "Folklor"],
                                                variantlar: ["Lirika", "Epos", "Drama", "Folklorshunoslik"],
                        togri: 3
                    },
                    {
                        savol: "G'afur G'ulomning 'Shum bola' asari qahramoni?",
                        variantlar: ["Qoravoy", "Shum bola", "O'tkir", "Hasan"],
                        togri: 1
                    },
                    {
                        savol: "Aqliy she'r janri asoschisi?",
                        variantlar: ["Erkin Vohidov", "Abdulla Oripov", "Muhammad Yusuf", "Rauf Parfi"],
                        togri: 0
                    },
                    {
                        savol: "Oybekning 'Qutlug' qon' asari nima haqida?",
                        variantlar: ["Tarixiy", "Zamonaviy", "Ishqiy", "Sarguzasht"],
                        togri: 0
                    },
                    {
                        savol: "Cho'lponning asl ismi?",
                        variantlar: ["Abdulhamid", "Sulaymon", "Muhammad", "Abdurahmon"],
                        togri: 0
                    },
                    {
                        savol: "Abdulla Qahhorning mashhur hikoyasi?",
                        variantlar: ["O'tgan kunlar", "Mehrobdan chayon", "Sinchalak", "Bemor"],
                        togri: 2
                    },
                    {
                        savol: "Maqom nima?",
                        variantlar: ["Musiqiy asar", "She'riy janr", "Tarixiy asar", "Doston"],
                        togri: 0
                    },
                    {
                        savol: "Dostonlar qahramoni?",
                        variantlar: ["Alpomish", "Avaz", "Gorogli", "Hammasi"],
                        togri: 3
                    },
                    {
                        savol: "Ogahiy qaysi sohada ijod qilgan?",
                        variantlar: ["Tarix va she'riyat", "Falsafa", "Tibbiyot", "Astronomiya"],
                        togri: 0
                    },
                    {
                        savol: "Zulfiya qachon tug'ilgan?",
                        variantlar: ["1915", "1920", "1925", "1930"],
                        togri: 0
                    },
                    {
                        savol: "O'zbekiston Qahramoni unvoni berilgan shoir?",
                        variantlar: ["Abdulla Oripov", "Erkin Vohidov", "Muhammad Yusuf", "Hammasi"],
                        togri: 3
                    },
                    {
                        savol: "Sayfi Saroyi qaysi asrda yashagan?",
                        variantlar: ["XIV", "XV", "XVI", "XVII"],
                        togri: 0
                    },
                    {
                        savol: "Nasriy asar turlari?",
                        variantlar: ["Hikoya, qissa, roman", "She'r, doston", "Tragediya, komediya", "Maqol, topishmoq"],
                        togri: 0
                    },
                    {
                        savol: "Lutfiyning she'rlari qaysi tilda?",
                        variantlar: ["Arab", "Fors", "Turkiy", "Mo'g'ul"],
                        togri: 2
                    },
                    {
                        savol: "Atoiy qaysi asrda yashagan?",
                        variantlar: ["XIV-XV", "XV-XVI", "XVI-XVII", "XVII-XVIII"],
                        togri: 0
                    },
                    {
                        savol: "Munojot janri nima haqida?",
                        variantlar: ["Ishq", "Tabiat", "Ilohiy muhabbat", "Vatan"],
                        togri: 2
                    },
                    {
                        savol: "Hamsa nima?",
                        variantlar: ["Besh doston", "Beshta she'r", "Besh hikoya", "Besh maqola"],
                        togri: 0
                    },
                    {
                        savol: "Temur tuzuklari qaysi tilda yozilgan?",
                        variantlar: ["O'zbek", "Fors", "Arab", "Chig'atoy"],
                        togri: 3
                    }
                ]
            },
            "ingliz-tili": {
                nomi: 'Ingliz tili',
                savollar: [
                    {
                        savol: "'Hello' so'zining ma'nosi?",
                        variantlar: ["Salom", "Xayr", "Rahmat", "Iltimos"],
                        togri: 0
                    },
                    {
                        savol: "I ___ a student.",
                        variantlar: ["is", "am", "are", "be"],
                        togri: 1
                    },
                    {
                        savol: "'Book' so'zining ma'nosi?",
                        variantlar: ["Kitob", "Daftar", "Qalam", "Ruchka"],
                        togri: 0
                    },
                    {
                        savol: "___ is your name?",
                        variantlar: ["What", "Who", "Where", "When"],
                        togri: 0
                    },
                    {
                        savol: "They ___ playing football.",
                        variantlar: ["is", "am", "are", "be"],
                        togri: 2
                    },
                    {
                        savol: "'Good morning' so'zining ma'nosi?",
                        variantlar: ["Xayrli tong", "Xayrli kun", "Xayrli kech", "Xayrli tun"],
                        togri: 0
                    },
                    {
                        savol: "Ranglar ichida 'red' qaysi?",
                        variantlar: ["Qizil", "Ko'k", "Sariq", "Yashil"],
                        togri: 0
                    },
                    {
                        savol: "Sonlardan 'ten' qaysi?",
                        variantlar: ["5", "8", "10", "12"],
                        togri: 2
                    },
                    {
                        savol: "Olmoshlardan 'we' qaysi?",
                        variantlar: ["Men", "Sen", "U", "Biz"],
                        togri: 3
                    },
                    {
                        savol: "Hafta kunlaridan 'Monday' qaysi?",
                        variantlar: ["Dushanba", "Seshanba", "Chorshanba", "Payshanba"],
                        togri: 0
                    },
                    {
                        savol: "Oilada 'mother' kim?",
                        variantlar: ["Ona", "Ota", "Aka", "Uka"],
                        togri: 0
                    },
                    {
                        savol: "Fe'llardan 'go' qaysi?",
                        variantlar: ["Kelmoq", "Ketmoq", "Bormoq", "Turmoq"],
                        togri: 2
                    },
                    {
                        savol: "Sifatlardan 'big' qaysi?",
                        variantlar: ["Kichik", "Katta", "Yangi", "Eski"],
                        togri: 1
                    },
                    {
                        savol: "Predloglardan 'in' qaysi?",
                        variantlar: ["Ustida", "Ichida", "Yonida", "Orqasida"],
                        togri: 1
                    },
                    {
                        savol: "So'roq so'zlardan 'why' qaysi?",
                        variantlar: ["Nima", "Qayer", "Qachon", "Nega"],
                        togri: 3
                    },
                    {
                        savol: "Zamonlardan Present Simple qaysi?",
                        variantlar: ["Hozirgi oddiy", "O'tgan oddiy", "Kelasi oddiy", "Hozirgi davomiy"],
                        togri: 0
                    },
                    {
                        savol: "Ko'plik yasovchi qo'shimcha?",
                        variantlar: ["-s/-es", "-ed", "-ing", "-er"],
                        togri: 0
                    },
                    {
                        savol: "Noto'g'ri fe'llardan biri?",
                        variantlar: ["Play", "Work", "Go", "Live"],
                        togri: 2
                    },
                    {
                        savol: "Artikl qaysi?",
                        variantlar: ["a/an", "in/on", "at/to", "for/with"],
                        togri: 0
                    },
                    {
                        savol: "Taqqoslash darajasi qaysi qo'shimcha?",
                        variantlar: ["-er/-est", "-ly", "-ful", "-less"],
                        togri: 0
                    },
                    {
                        savol: "Modal fe'llardan biri?",
                        variantlar: ["Can", "Have", "Do", "Make"],
                        togri: 0
                    },
                    {
                        savol: "Olmoshlarning obyekt formasi?",
                        variantlar: ["me, him, her", "I, he, she", "my, his, her", "mine, his, hers"],
                        togri: 0
                    },
                    {
                        savol: "So'z yasovchi qo'shimcha?",
                        variantlar: ["-tion", "-ed", "-ing", "-s"],
                        togri: 0
                    },
                    {
                        savol: "Frazeologik fe'llardan biri?",
                        variantlar: ["Get up", "Sleep", "Walk", "Run"],
                        togri: 0
                    },
                    {
                        savol: "Ingliz tilidagi vaqtlar soni?",
                        variantlar: ["8", "10", "12", "14"],
                        togri: 2
                    }
                ]
            }
        };

        // Global o'zgaruvchilar
        let currentFan = 'matematika';
        let currentIndex = 0;
        let userAnswers = {};
        let testTugadi = false;

        // DOM elementlari
        const fanCards = document.querySelectorAll('.fan-card');
        const fanNomiElement = document.getElementById('fanNomi');
        const currentQuestionElement = document.getElementById('currentQuestion');
        const totalQuestionsElement = document.getElementById('totalQuestions');
        const questionsContainer = document.getElementById('questionsContainer');
        const progressFill = document.getElementById('progressFill');
        const resultContainer = document.getElementById('resultContainer');
        const testSection = document.getElementById('testSection');
        const oldinBtn = document.getElementById('oldinBtn');
        const keyingiBtn = document.getElementById('keyingiBtn');
        const tekshirishBtn = document.getElementById('tekshirishBtn');
        const qaytaBtn = document.getElementById('qaytaBtn');

        // Fan kartalariga event listener qo'shish
        fanCards.forEach(card => {
            card.addEventListener('click', () => {
                const fan = card.dataset.fan;
                fanTanlash(fan);

                // Active classni yangilash
                fanCards.forEach(c => c.classList.remove('active'));
                card.classList.add('active');
            });
        });

        // Fanni tanlash funksiyasi
        function fanTanlash(fan) {
            currentFan = fan;
            currentIndex = 0;
            userAnswers = {};
            testTugadi = false;

            // UI yangilash
            fanNomiElement.textContent = testlar[fan].nomi;
            totalQuestionsElement.textContent = testlar[fan].savollar.length;
            updateProgress();

            // Test sectionni ko'rsatish
            testSection.classList.remove('hidden');
            resultContainer.classList.add('hidden');

            // Savollarni yuklash
            renderQuestions();

            // Tugmalarni holatini yangilash
            updateButtons();
        }

        // Savollarni render qilish
        function renderQuestions() {
            const savollar = testlar[currentFan].savollar;
            let html = '';

            savollar.forEach((savol, index) => {
                const isActive = index === currentIndex ? 'style="display: block;"' : 'style="display: none;"';
                const selectedAnswer = userAnswers[index] !== undefined ? userAnswers[index] : -1;

                html += `
                    <div class="question" id="question-${index}" ${isActive}>
                        <div class="question-text">${index + 1}. ${savol.savol}</div>
                        <div class="options">
                `;

                savol.variantlar.forEach((variant, vIndex) => {
                    const isSelected = selectedAnswer === vIndex ? 'selected' : '';
                    html += `
                        <div class="option ${isSelected}" onclick="selectAnswer(${index}, ${vIndex})">
                            <input type="radio" name="question-${index}" value="${vIndex}" ${isSelected ? 'checked' : ''}>
                            <span>${variant}</span>
                        </div>
                    `;
                });

                html += `
                        </div>
                    </div>
                `;
            });

            questionsContainer.innerHTML = html;
            currentQuestionElement.textContent = currentIndex + 1;
        }

        // Javob tanlash
        window.selectAnswer = function(questionIndex, answerIndex) {
            userAnswers[questionIndex] = answerIndex;

            // Highlight tanlangan javobni
            const options = document.querySelectorAll(`#question-${questionIndex} .option`);
            options.forEach(opt => opt.classList.remove('selected'));
            options[answerIndex].classList.add('selected');

            // Radio buttonni belgilash
            const radio = document.querySelector(`#question-${questionIndex} input[value="${answerIndex}"]`);
            if (radio) radio.checked = true;

            // Progressni yangilash
            updateProgress();
        }

        // Oldingi savol
        window.oldingiSavol = function() {
            if (currentIndex > 0) {
                document.getElementById(`question-${currentIndex}`).style.display = 'none';
                currentIndex--;
                document.getElementById(`question-${currentIndex}`).style.display = 'block';
                currentQuestionElement.textContent = currentIndex + 1;
                updateButtons();
            }
        }

        // Keyingi savol
        window.keyingiSavol = function() {
            const savollar = testlar[currentFan].savollar;
            if (currentIndex < savollar.length - 1) {
                document.getElementById(`question-${currentIndex}`).style.display = 'none';
                currentIndex++;
                document.getElementById(`question-${currentIndex}`).style.display = 'block';
                currentQuestionElement.textContent = currentIndex + 1;
                updateButtons();
            }
        }

        // Tugmalar holatini yangilash
        function updateButtons() {
            const savollar = testlar[currentFan].savollar;
            oldinBtn.disabled = currentIndex === 0;
            keyingiBtn.disabled = currentIndex === savollar.length - 1;
        }

        // Progressni yangilash
        function updateProgress() {
            const javoblarSoni = Object.keys(userAnswers).length;
            const umumiySavollar = testlar[currentFan].savollar.length;
            const foiz = (javoblarSoni / umumiySavollar) * 100;
            progressFill.style.width = foiz + '%';
        }

        // Testni tekshirish
        window.tekshirish = function() {
            const savollar = testlar[currentFan].savollar;
            let togri = 0;

            savollar.forEach((savol, index) => {
                if (userAnswers[index] !== undefined && userAnswers[index] === savol.togri) {
                    togri++;
                }
            });

            const notogri = Object.keys(userAnswers).length - togri;
            const foiz = (togri / savollar.length * 100).toFixed(1);

            // Natijalarni ko'rsatish
            document.getElementById('resultScore').textContent = `${togri}/${savollar.length}`;
            document.getElementById('correctCount').textContent = togri;
            document.getElementById('incorrectCount').textContent = notogri;
            document.getElementById('percentage').textContent = foiz + '%';

            // Test sectionni yashirish, natijani ko'rsatish
            document.querySelector('.test-header').style.display = 'none';
            document.getElementById('questionsContainer').style.display = 'none';
            document.querySelector('.test-controls').style.display = 'none';
            document.querySelector('.progress-bar').style.display = 'none';
            resultContainer.classList.remove('hidden');

            testTugadi = true;
        }

        // Qayta boshlash
        window.qaytaBoshlash = function() {
            userAnswers = {};
            currentIndex = 0;
            testTugadi = false;

            // Test sectionni ko'rsatish
            document.querySelector('.test-header').style.display = 'flex';
            document.getElementById('questionsContainer').style.display = 'block';
            document.querySelector('.test-controls').style.display = 'flex';
            document.querySelector('.progress-bar').style.display = 'block';
            resultContainer.classList.add('hidden');

            // Savollarni qayta render qilish
            renderQuestions();
            updateProgress();
            updateButtons();
        }

        // Dastlabki fanni yuklash
        fanTanlash('matematika');